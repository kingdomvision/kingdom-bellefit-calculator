<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );

$fields = json_decode(file_get_contents('php://input'));
$ngObject = array();
$status = "error";

/* MailChimp Add Email Code Start */
$week_email = $fields->week_email;
if( !empty($week_email) ) {
	$mailchimp_api_key = get_option('_bellefit_mailchimp_api');
	$mailchimp_list_id = get_option('_bellefit_mailchimp_list');
	
	require_once 'mailchimp/MCAPI.class.php';
	$api = new MCAPI($mailchimp_api_key);
	$merge_vars = array('FNAME' => '', 'LNAME' => '');
	
	
	$retval = $api->listSubscribe( $mailchimp_list_id, $week_email, $merge_vars, 'html', false, true );
	
	$status = "success";
}
/* MailChimp Add Email Code Ended */

$ngObject['status'] = $status;
echo json_encode( $ngObject );
exit;
?>