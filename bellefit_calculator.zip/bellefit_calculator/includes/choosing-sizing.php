<?php
$ex_wpdb = external_wpdb();
global $wpdb;
?>

<h1>Choosing & Sizing Forms</h1>
<div class="wrap">
    <?php if (isset($_GET['action']) && $_GET['action'] == 'delete_all') {
        $bulk_action = $_POST['bulk_action'];
        $cal_step_ids = $_POST['cal_step_ids'];
        $total_record = count($cal_step_ids);
        if ($bulk_action == 'delete' && $total_record) {
            foreach($cal_step_ids as $cal_step_id) {
                $ex_wpdb->query('DELETE FROM cal_step_save WHERE cal_step_id = '.$cal_step_id.'');
            } ?>
            <div class="updated notice is-dismissible" id="message"><p><?php echo $total_record; ?> Record's Deleted.</p><button class="notice-dismiss" type="button"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
            <?php
        }

    } ?>
    <?php if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        $cal_step_id = $_GET['id'];
        $ex_wpdb->query('DELETE FROM cal_step_save WHERE cal_step_id = '.$cal_step_id.'');
        ?> <div class="updated notice is-dismissible" id="message"><p>1 Record Deleted.</p><button class="notice-dismiss" type="button"><span class="screen-reader-text">Dismiss this notice.</span></button></div> <?php
    } ?>
    
    <?php if (isset($_GET['action']) && $_GET['action'] == 'view') { ?>
    
        <?php
		if (isset($_GET['id'])) {
			$cal_step_id = $_GET['id'];
			$forms_data = $ex_wpdb->get_results('SELECT * FROM cal_step_save WHERE cal_step_id = '.$cal_step_id.' ', OBJECT);
		} 
	    foreach($forms_data as $data) {
            ?>
            <div class="form_details">
                <div class="form_details_head">
                    ID : 
                </div>
                <div class="form_details_value">
                    <?php echo $data->cal_key; ?>
                </div>
            </div>
            <?php
            $user_id = $data->user_id;
            if ($user_id) {
                $user_data = get_user_by('ID', $user_id);
                $user_info = $user_data->data;
                $user_name = $user_info->display_name;
            } else {
                $user_name = 'Guest User';
            }
            ?>
            <div class="form_details">
                <div class="form_details_head">
                    User Name : 
                </div>
                <div class="form_details_value">
                    <?php echo $user_name; ?>
                </div>
            </div>
            <?php
            $status = $data->status;
            if ($status == '1') {
                $status_name = 'Completed Form';
            } else if ($status == '2') {
                $status_name = 'Completed Form - Paid';
            } else if ($status == '0') {
                $status_name = 'Partially Filled Form';
            }
            ?>
            <div class="form_details">
                <div class="form_details_head">
                    Status : 
                </div>
                <div class="form_details_value">
                    <?php echo $status_name; ?>
                </div>
            </div>
            <div class="form_details">
                <div class="form_details_head">
                    Date : 
                </div>
                <div class="form_details_value">
                    <?php $date = 'date'; echo date("F, d Y h:i:s", strtotime($data->$date)); ?>
                </div>
            </div>
            <div class="form_details">
                <div class="form_details_head">
                    User IP : 
                </div>
                <div class="form_details_value">
                    <?php echo $data->ip; ?>
                </div>
            </div>
            <?php
            $cal_value = $data->cal_value;
            $cal_value = unserialize($cal_value);
			/*echo '<pre>';
			print_r($cal_value);
			echo '</pre>';*/
			$reorder_cal_value = array();
			
			if (isset($cal_value->give_birth)) {
				$reorder_cal_value['Did already give birth'] = $cal_value->give_birth;
			}
			
			if (isset($cal_value->give_birth_date)) {
				$reorder_cal_value['When did give birth'] = $cal_value->give_birth_date;
			} else if ( isset($cal_value->give_birth_month) && isset($cal_value->give_birth_day) && isset($cal_value->give_birth_year) ) { 
				$reorder_cal_value['When did give birth'] = $cal_value->give_birth_month.'-'.$cal_value->give_birth_day.'-'.$cal_value->give_birth_year; 
			}
			
			if (isset($cal_value->birth_by_csection)) {
				$reorder_cal_value['Did give birth by C-Section'] = $cal_value->birth_by_csection;
			}
			
			if (isset($cal_value->plan_on_csection)) {
				$reorder_cal_value['Plan on having a C-Section'] = $cal_value->plan_on_csection;
			}
			
			if (isset($cal_value->how_many_week)) {
				$reorder_cal_value['Pre-Pregnancy Weight, weeks'] = $cal_value->how_many_week;
			}
			
			if (isset($cal_value->measure_week)) {
				$reorder_cal_value['Receive a Sizing Reminder'] = $cal_value->measure_week;
			}
			
			if (isset($cal_value->week_email)) {
				$reorder_cal_value['Email'] = $cal_value->week_email;
			}
			
			if (isset($cal_value->postpartum_swelling)) {
				$reorder_cal_value['Post-Baby Pooch Swelling'] = $cal_value->postpartum_swelling;
			}
			
			if (isset($cal_value->_2_pregnancy_weight)) {
				$reorder_cal_value['Pre-Pregnancy Weight'] = $cal_value->_2_pregnancy_weight . ' Lb';
			}
			
			if (isset($cal_value->_2_heaviest_weight)) {
				$reorder_cal_value['Weight Just Before Gave Birth'] = $cal_value->_2_heaviest_weight . ' Lb';
			}
			
			if (isset($cal_value->_2_weight_now)) {
				$reorder_cal_value['Weight Now'] = $cal_value->_2_weight_now . ' Lb';
			}
			
			if (isset($cal_value->pregnancy_gained)) {
				$reorder_cal_value['During Pregnance Gaines'] = $cal_value->pregnancy_gained . ' Lb';
			}
			
			if (isset($cal_value->after_childbirth)) {
				$reorder_cal_value['From Giving Birth Until Now, Lost'] = $cal_value->after_childbirth . ' Lb';
			}
			
			if (isset($cal_value->remain_weight)) {
				$reorder_cal_value['Remaining Weight Left to Lose'] = $cal_value->remain_weight . ' Lb';
			}
			
			if (isset($cal_value->pregnancy_weight_no)) {
				$reorder_cal_value['Pre-Pregnancy Weight'] = $cal_value->pregnancy_weight_no . ' Lb';
			}
			
			if (isset($cal_value->weight_now_no)) {
				$reorder_cal_value['Your Weight Now'] = $cal_value->weight_now_no . ' Lb';
			}
			
			if (isset($cal_value->weight_gain_pregnant)) {
				$reorder_cal_value['During Your Pregnance You Gain'] = $cal_value->weight_gain_pregnant . ' Lb';
			}
			
			if (isset($cal_value->tall_are_you)) {
				$reorder_cal_value['How Tall'] = $cal_value->tall_are_you;
			}
			
			if (isset($cal_value->carry_your_weight)) {
				$reorder_cal_value['Where do tend to carry weight'] = $cal_value->carry_your_weight;
			}
			
			if (isset($cal_value->body_shapes)) {
				$reorder_cal_value['Body Shapes'] = $cal_value->body_shapes;
			}
			
			if (isset($cal_value->pregnancy_jean_size)) {
				$reorder_cal_value['Pre-Pregnancy Jean Size'] = $cal_value->pregnancy_jean_size;
			}
			
			if (isset($cal_value->your_hip_contour)) {
				$reorder_cal_value['Measure Hip Contour'] = $cal_value->your_hip_contour;
			}
			
			if (isset($cal_value->measuring_inches)) {
				$reorder_cal_value['Hip Measurement in Inches'] = $cal_value->measuring_inches;
			}
			
            foreach ($reorder_cal_value as $key => $value) {
				if ($key != 'model' && $key != 'uniqid') {
					?>
					<div class="form_details">
						<div class="form_details_head">
							<?php echo $key . ' :'; ?> 
						</div>
						<div class="form_details_value">
							<?php echo $value; ?>
						</div>
					</div>
					<?php
				}
            }
        }
        ?>

    <?php } else { ?>
        <?php
            $per_page = 25;
            if (isset($_GET['pageno'])) {
                $current_page = $_GET['pageno'];
            } else {
                $current_page = 1;
            }
            if ($current_page == 1) {
                $start_record = 0;
            } else {
                $start_record = ($current_page * $per_page) - $per_page;
            }
			
			$where = '';
			$where_status = '';
			$status_relation = '';
			$where_userip = '';
			$userip_relation = '';
			$where_date = '';
			
			if (isset($_GET['status']) && $_GET['status'] != '' || isset($_GET['userip']) && $_GET['userip'] != '' || isset($_GET['date']) && $_GET['date'] != '') {
				$where .= ' WHERE';
			}
			
			if (isset($_GET['status']) && $_GET['status'] != '') {
				if ($_GET['status'] == 'completed_form') { $where_status = ' status = 1'; }
				if ($_GET['status'] == 'completed_form_paid') { $where_status = ' status = 2'; }
				if ($_GET['status'] == 'partially_form') { $where_status = ' status = 0'; }
			}
			
			if (isset($_GET['userip']) && $_GET['userip'] != '') {
				$userip = $_GET['userip'];
				$where_userip = " ip = '".$userip."'";
			}
			
			if ($where_userip != '' && $where_status != '') {
				$status_relation = ' AND';
			}
			
			if (isset($_GET['date']) && $_GET['date'] != '') {
				$dates = explode(',', $_GET['date']);
				$dateFrom = date('Y-m-d 00:00:00', strtotime($dates[0]));
				$dateTo = date('Y-m-d 00:00:00', strtotime($dates[1] . "+1 days"));
				$where_date = ' ( date BETWEEN "'.$dateFrom.'" AND "'.$dateTo.'" )';
			}
			
			if ($where_userip != '' && $where_date != '' || $where_status != '' && $where_date != '') {
				$userip_relation = ' AND';
			}
			
            $forms_count = $ex_wpdb->get_results('SELECT count(*) FROM cal_step_save'. $where . $where_status . $status_relation . $where_userip . $userip_relation . $where_date . ' ORDER BY cal_step_id DESC', OBJECT); ?>
        <?php foreach($forms_count as $count) {
            $cnt = 'count(*)';
            $total_rec = $count->$cnt;
        } ?>
        <?php 
		//echo 'SELECT * FROM cal_step_save'. $where . $where_status . $status_relation . $where_userip . $userip_relation . $where_date . ' ORDER BY cal_step_id DESC LIMIT '.$start_record.', '.$per_page;
		$forms_data = $ex_wpdb->get_results('SELECT * FROM cal_step_save'. $where . $where_status . $status_relation . $where_userip . $userip_relation . $where_date . ' ORDER BY cal_step_id DESC LIMIT '.$start_record.', '.$per_page.' ', OBJECT);
		
		$pagination_link = '';
		if (isset($_GET['pageno']) && $_GET['pageno'] != '') {
			$pagination_link = '&pageno='.$_GET['pageno'];
		}
		$status_link = '';
		if (isset($_GET['status']) && $_GET['status'] != '') {
			$status = $_GET['status'];
			$status_link = '&status='.$status;
		}
		$userip_link = '';
		if (isset($_GET['userip']) && $_GET['userip'] != '') {
			$uip = $_GET['userip'];
			$userip_link = '&userip='.$uip;
		}
		
		$date_link = '';
		if (isset($_GET['date']) && $_GET['date'] != '') {
			$dt = $_GET['date'];
			$date_link = '&date='.$dt;
		}
		
        ?>
        <div class="status_filter_top">
        	<?php
			$extra_relation = '';
			$extra_relation2 = '';
			if ($where_userip != '' || $where_date != '') {
				$wh = ' WHERE';
			}
			
			if ($where_userip != '') {
				$extra_relation = ' AND';
			}
			if ($where_userip == '' && $where_date != '') {
				$extra_relation = ' AND';
				$extra_relation2 = '';
			}
			
			if ($where_userip != '' && $where_date != '') {
				$extra_relation = ' AND';
				$extra_relation2 = ' AND';
			}
			
			$status_all_count = $ex_wpdb->get_results('SELECT cal_step_id FROM cal_step_save'. $wh . $where_userip . $extra_relation2 . $where_date, OBJECT);
			$status_all_cnt = $ex_wpdb->num_rows;

			$status_partially_count = $ex_wpdb->get_results('SELECT cal_step_id FROM cal_step_save WHERE status = "0"'. $extra_relation . $where_userip . $extra_relation2 . $where_date, OBJECT);
			$status_partially_cnt = $ex_wpdb->num_rows;
						
			$status_completed_count = $ex_wpdb->get_results('SELECT cal_step_id FROM cal_step_save WHERE status = "1"'. $extra_relation . $where_userip . $extra_relation2 . $where_date, OBJECT);
			$status_completed_cnt = $ex_wpdb->num_rows;
			
			$status_paid_count = $ex_wpdb->get_results('SELECT cal_step_id FROM cal_step_save WHERE status = "2"'. $extra_relation . $where_userip . $extra_relation2 . $where_date, OBJECT);
			$status_paid_cnt = $ex_wpdb->num_rows;
						
			if (!isset($_GET['status'])) {
				$status_all = '<strong>All ('.$status_all_cnt.')</strong>';
			} else {
				$status_all = '<a href="'.admin_url().'admin.php?page=bellefit-calculator'.$userip_link.$date_link.'" style="text-decoration:none">All ('.$status_all_cnt.')</a>';
			}
			if (isset($_GET['status']) && $_GET['status'] == 'partially_form') {
				$status_partially = '<strong>Partially Filled Form ('.$status_partially_cnt.')</strong>';
			} else {
				$status_partially = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=partially_form'.$userip_link.$date_link.'" style="text-decoration:none">Partially Filled Form ('.$status_partially_cnt.')</a>';
			}
			if (isset($_GET['status']) && $_GET['status'] == 'completed_form') {
				$status_completed = '<strong>Completed Form ('.$status_completed_cnt.')</strong>';
			} else {
				$status_completed = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=completed_form'.$userip_link.$date_link.'" style="text-decoration:none">Completed Form ('.$status_completed_cnt.')</a>';
			}
			if (isset($_GET['status']) && $_GET['status'] == 'completed_form_paid') {
				$status_completed_paid = '<strong>Completed Form - Paid ('.$status_paid_cnt.')</strong>';
			} else {
				$status_completed_paid = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=completed_form_paid'.$userip_link.$date_link.'" style="text-decoration:none">Completed Form Paid ('.$status_paid_cnt.')</a>';
			}
			
			?>
            
        	<?php echo $status_all; ?> | <?php echo $status_partially; ?> | <?php echo $status_completed; ?> | <?php echo $status_completed_paid; ?></a>
        </div>
        <form method="post" action="<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&action=delete_all<?php echo $pagination_link . $status_link . $userip_link . $date_link; ?>" >
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <label class="screen-reader-text" for="bulk-action-selector-top">Select bulk action</label>
                    <select id="bulk-action-selector-top" name="bulk_action">
                        <option value="">Bulk Actions</option>
                        <option value="delete">Delete</option>
                    </select>
                    <input type="submit" value="Apply" class="button action" id="doaction">
                </div>
                
                <div class="filter_userip" style="float:right; margin-right:5px;">
                    <label>Select User IP</label>
                    <?php
					?>
                    <select id="filter-userip" name="filter_userip">
                        <option value="">All</option>
                        <?php
						$userips = $ex_wpdb->get_results("SELECT ip FROM cal_step_save GROUP BY ip ", OBJECT);
						if ($ex_wpdb->num_rows) {
							foreach($userips as $ip) {
								$selected = '';
								if (isset($_GET['userip']) && $_GET['userip'] == $ip->ip) {
									$selected = 'selected="selected"';
								}
								echo '<option value="'.$ip->ip.'" '.$selected.'>'.$ip->ip.'</option>';
							}
						}
						?>
                    </select>
                </div>
                
                <div class="filter_dates" style="float:right; margin-right:5px;">
                    <label>Select Dates</label>
                    <?php
					$dateFrom = '';
					$dateTo = '';
					if (isset($_GET['date']) && $_GET['date'] != '') {
						$dates = explode(',', $_GET['date']);
						$dateFrom = $dates[0];
						$dateTo = $dates[1];
					}
					?>
                    <input type="date" id="datepicker1" name="date_from" value="<?php echo $dateFrom; ?>" readonly />
                    <label>To</label>
                    <input type="date" id="datepicker2" name="date_to" value="<?php echo $dateTo; ?>" readonly />&nbsp;
                    <input type="button" id="date_filter" class="button action" value="Filter">
                    <?php
					if (isset($_GET['date']) && $_GET['date'] != '') { ?>
						<a href="<?php echo admin_url(); ?>admin.php?page=bellefit-calculator<?php echo $status_link.$userip_link; ?>">Reset</a>
					<?php }
					?>
                </div>
                
            </div>
            <table class="wp-list-table widefat fixed striped posts">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column" id="cb">
                            <label for="cb-select-all-1" class="screen-reader-text">Select All</label>
                            <input type="checkbox" id="select_all_forms">
                        </td>
                        <th class="manage-column"scope="col"><span>ID</span></th>
                        <th class="manage-column" scope="col">User Name</th>
                        <th class="manage-column" scope="col">Status</th>
                        <th class="manage-column" scope="col">Date</th>
                        <th class="manage-column" scope="col">User IP</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                foreach($forms_data as $data) {
                    ?>
                    <tr>
                        <td>
                            <input type="checkbox" value="<?php echo $data->cal_step_id; ?>" name="cal_step_ids[]" class="select_form" />
                        </td>
                        <td>
                            <a href="<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&action=view&id=<?php echo $data->cal_step_id; ?>"><?php echo $data->cal_key; ?></a>
                            <div class="row-actions">
                                <span class="view">
                                    <a href="<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&action=view&id=<?php echo $data->cal_step_id; ?>">View</a>
                                </span>&nbsp;|&nbsp;
                                <?php if ($data->status == '2') {
									$calculator_key = $data->cal_key;
									$order_query = $wpdb->get_row("SELECT order_id FROM cal_form_order_data WHERE cal_id = '$calculator_key'");
									$order_id = $order_query->order_id;
									$prefix = $wpdb->prefix;
									$main_order_query = $wpdb->get_row("SELECT * FROM " . $prefix . "woocommerce_order_items WHERE order_item_id = '$order_id'");
									$main_order_id = $main_order_query->order_id;
								?>
                                	<span class="view">
                                        <a href="<?php echo get_edit_post_link($main_order_id); ?>">View Order</a>
                                    </span>&nbsp;|&nbsp;
                                
                                <?php } ?>
                                <span class="trash">
                                    <a href="<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&action=delete&id=<?php echo $data->cal_step_id . $pagination_link . $status_link . $userip_link . $date_link; ?>">Delete</a>
                                </span>
                            </div>
                        </td>
                        <?php
                        $user_id = $data->user_id;
                        if ($user_id) {
                            $user_data = get_user_by('ID', $user_id);
                            $user_info = $user_data->data;
							if ($data->status == '2') {
                            	$user_name = '<a href="'.admin_url().'edit.php?post_type=shop_order&_customer_user='.$user_id.'">'.$user_info->display_name.'</a>';
							} else {
								$user_name = $user_info->display_name;
							}
                        } else {
                            $user_name = 'Guest User';
                        }
                        ?>
                        <td><?php echo $user_name; ?></td>
                        <?php
                        $status = $data->status;
                        if ($status == '1') {
                            $status_name = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=completed_form'.$userip_link.$date_link.'">Completed Form</a>';
                        } else if ($status == '2') {
                            $status_name = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=completed_form_paid'.$userip_link.$date_link.'">Completed Form - Paid</a>';
                        } else if ($status == '0') {
                            $status_name = '<a href="'.admin_url().'admin.php?page=bellefit-calculator&status=partially_form'.$userip_link.$date_link.'">Partially Filled Form</a>';
                        }
                        ?>
                        <td><?php echo $status_name; ?></td>
                        <td><?php $date = 'date'; echo date("F, d Y h:i:s", strtotime($data->$date)); ?></td>
                        <td><?php echo $data->ip; ?></td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </form>
        <div class="pagination">
        	<?php
			$end_rec = $start_record + $per_page;
			if ( $end_rec > $total_rec) {
				$end_rec = $total_rec;
			} 
			?>
        	<div class="page_stat">Showing <?php if (!$end_rec) echo '0'; else echo $start_record + 1; ?> - <?php echo $end_rec; ?> of <?php echo $total_rec; ?> Records</div>
            <?php
			$total_pages = $total_rec / $per_page;
			$total_pages = ceil($total_pages);
			if ($total_pages > 1) {
			?>
            <div class="paging">
            	<?php for ($pg = 1; $pg <= $total_pages; $pg++) { ?>
                	<?php 
					$page_link = admin_url() . 'admin.php?page=bellefit-calculator&pageno='.$pg; 
					?>
					<span class="paged <?php if ($current_page == $pg) echo 'active'; ?>"><a href="<?php echo $page_link.$status_link.$userip_link.$date_link; ?>"><?php echo $pg; ?></a></span>
				<?php } ?>
            </div>
            <?php } ?>
        </div>
        <script>
        	jQuery(document).ready(function(e) {
				
				jQuery('#datepicker1').datepicker();
				jQuery('#datepicker2').datepicker();
				
				jQuery("#filter-userip").on("change", function() {
					var $filter = jQuery(this).val();
					var $status = '';
					var $date = '';
					<?php
					if (isset($_GET['status']) && $_GET['status'] != '') { ?>
						$status = '&status=' + '<?php echo $_GET['status']; ?>';
					<?php }
					if (isset($_GET['date']) && $_GET['date'] != '') { ?>
						$date = '&date=' + '<?php echo $_GET['date']; ?>';
					<?php }	?>
					if ($filter != '') {
						window.location.assign('<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&userip='+$filter + $status + $date);
					} else {
						window.location.assign('<?php echo admin_url(); ?>admin.php?page=bellefit-calculator' + $status + $date);
					}
				});
				
				jQuery("#date_filter").click(function() {
					var dateFrom = jQuery("#datepicker1").val();
					if (dateFrom == '') {
						alert('Please Select the Valid Date');
						jQuery("#datepicker1").focus();
						return false;
					}
					var dateTo = jQuery("#datepicker2").val();
					if (dateTo == '') {
						alert('Please Select the Valid Date');
						jQuery("#datepicker2").focus();
						return false;
					}
					var $filter = dateFrom + "," + dateTo;
					var $status = '';
					var $userip = '';
					<?php
					if (isset($_GET['status']) && $_GET['status'] != '') { ?>
						$status = '&status=' + '<?php echo $_GET['status']; ?>';
					<?php }
					if (isset($_GET['userip']) && $_GET['userip'] != '') { ?>
						$userip = '&userip=' + '<?php echo $_GET['userip']; ?>';
					<?php }	?>
					window.location.assign('<?php echo admin_url(); ?>admin.php?page=bellefit-calculator&date='+$filter + $status + $userip);
					
				});
            });
        </script>
    <?php } ?>
</div>