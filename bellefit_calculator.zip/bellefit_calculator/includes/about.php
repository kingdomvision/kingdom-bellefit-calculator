<h1>About</h1>
<p>This plugin is custom coded by <a href="http://kingdom-vision.com/" target="_blank">Kingdom Vision</a> Web Development Ltd.</p>

<p>Software Used</p>
<p>Angular JS</p>
<p>PHP</p>

<h3>Development Team</h3>

<table width="600" border="0" cellpadding="5">
  <tbody>
    <tr>
      <td>Irfan Kaleem</td>
      <td>Project Manager</td>
      <td><a href="mailto:info@kingdom-vision.com">info@kingdom-vision.com</a></td>
    </tr>
    <tr>
      <td>Saad Qureshi</td>
      <td>Lead Developer</td>
      <td><a href="mailto:saad@kingdom-vision.co.uk">saad@kingdom-vision.co.uk</a></td>
    </tr>
    <tr>
      <td>Arfat Hussain</td>
      <td>Lead Designer</td>
      <td><a href="mailto:arfat@kingdom-vision.com">arfat@kingdom-vision.com</a></td>
    </tr>
    <tr>
      <td>Shahzad</td>
      <td>Supporting Developer</td>
      <td><a href="mailto:shahzad@kingdom-vision.com">shahzad@kingdom-vision.com</a></td>
    </tr>
    <tr>
      <td>Samad</td>
      <td>Supporting Designer</td>
      <td><a href="mailto:samad@kingdom-vision.com">samad@kingdom-vision.com</a></td>
    </tr>
    <tr>
      <td>Shahzad</td>
      <td>Q&A</td>
      <td><a href="mailto:shahzad@kingdom-vision.com">shahzad@kingdom-vision.com</a></td>
    </tr>
  </tbody>
</table>

<p>In case of any issue or bug - Please email to <a href="mailto:info@kingdom-vision.com">info@kingdom-vision.com</a></p>
