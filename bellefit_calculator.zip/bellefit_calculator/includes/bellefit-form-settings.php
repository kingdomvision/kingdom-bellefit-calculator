<?php 
function cal_get_field($object, $key) {
	$field = $object->$key;
	if( !empty($field) ) {
		$field_decode = esc_attr(htmlspecialchars_decode(wp_kses_decode_entities( stripslashes_deep($field) )));
		return $field_decode;
	}
	return '';
}

function cal_form_setting() {
	$form_setting = get_option( 'cal_form_setting' );
	$fields = json_decode($form_setting);
	return $fields;
}

function cal_input_text($name, $id = null, $object) {
	$field = sprintf( '<input type="text" name="%s" placeholder="%s" value="%s" />', $name, $id, cal_get_field($object, $name) );
	return $field;
}

function cal_input_number($name, $id = null, $object) {
	$field = sprintf('<input type="number" name="%s" id="%s" value="%s" />', $name, $id, cal_get_field($object, $name) );
	return $field;
}

function cal_input_radio($name, $id = null, $value, $object) {
	$field = sprintf(
					'<input type="radio" name="%s" id="%s" value="%s" %s />', 
					$name, $id, $value, 
					( cal_get_field($object, $name) == $value )? 'checked="checked"' : ''
				);
	return $field;
}

function cal_input_email($name, $id = null, $object) {
	$field = sprintf('<input type="email" name="%s" id="%s" value="%s" />', $name, $id, cal_get_field($object, $name) );
	return $field;
}

function cal_input_textarea($name, $id = null, $object) {
	$field = sprintf( '<textarea name="%s" id="%s" cols="60">%s</textarea>', $name, $id, cal_get_field($object, $name) );
	return $field;
}

function cal_input_upload($name, $path, $object) {
	//$field = sprintf( '<label>%s</label><input type="file" name="%s" />', $label, $name, cal_get_field($object, $name) );
	$get_field = cal_get_field($object, $name);
	$field = sprintf(
					'%s <input type="file" name="%s" />', 
					( $get_field != '' )? '<img src="'. Cal_URL .'/'. $path .'/'. $get_field .'" alt="'.$get_field.'" width="30" height="30" />' : '',
					$name
				);
	return $field;
}

function cal_file_upload($name, $path) {
	if ( isset($_FILES[$name]['size']) )
    {
		if(($_FILES[$name]["type"] == "image/gif")
		||($_FILES[$name]["type"] == "image/png")
		||($_FILES[$name]["type"] == "image/jpeg")
		&&($_FILES[$name]["size"] < (5242880)))//Maz size of file is 5 MB
		{
			//$uniqid		=	substr(uniqid(), 0, 30);
			$pathInfo	=	pathinfo($_FILES[$name]["name"], PATHINFO_EXTENSION);
			$fileName	=	$_FILES[$name]["name"];
			$tmp_name 	= 	$_FILES[$name]["tmp_name"];
			$isUploaded = 	move_uploaded_file($tmp_name, Cal_URI."/{$path}/" . $fileName);
			
			return $fileName;
		}
	}
	
	$image_results = cal_form_setting();
	if( !empty($image_results) ) {
		$get_image = cal_get_field($image_results, $name);
		return $get_image;
	}
	
	return '';
}

if( isset($_POST['submit']) ) {
	
	$_POST['text_measure_week'] = esc_html( $_POST['text_measure_week'] );
	$_POST['measuring_inches_img']  = cal_file_upload('measuring_inches_img', 'images');
	$_POST['printable_measure_img']  = cal_file_upload('printable_measure_img', 'images');
	$_POST['jean_size_img']  = cal_file_upload('jean_size_img', 'images');
	
	for($i=1; $i <= 4; $i++) {
		$field_name = 'head_tab_img_' . $i;
		$_POST[$field_name]  = cal_file_upload($field_name, 'images');
	}
	
	for($i=1; $i <= 5; $i++) {
		$field_name_inactive = 'body_shapes_in_' . $i;
		$field_name_active = 'body_shapes_act_' . $i;
		
		$_POST[$field_name_inactive]  = cal_file_upload($field_name_inactive, 'images/shapes');
		$_POST[$field_name_active]  = cal_file_upload($field_name_active, 'images/shapes');
	}
	
	$data = json_encode($_POST);
	/*echo "<pre>";
	print_r($_POST);
	echo "</pre>";
	exit;*/
	update_option( 'cal_form_setting', $data );
}

//$form_setting = cal_form_setting();
$fields = cal_form_setting();
/*echo "<pre>";
//print_r($fields);
echo "</pre>";*/
?>
<style type="text/css">
#tab-menu li a { text-transform: uppercase; }
</style>
<form method="post" enctype="multipart/form-data">
    
    <div id="ngtabs">
    
      <ul id="tab-menu">
        <li><a href="#tabs-1"><?php echo cal_get_field($fields, 'head_tab_1'); ?></a></li>
        <li><a href="#tabs-2"><?php echo cal_get_field($fields, 'head_tab_2'); ?></a></li>
        <li><a href="#tabs-3"><?php echo cal_get_field($fields, 'head_tab_3'); ?></a></li>
        <li><a href="#tabs-4"><?php echo cal_get_field($fields, 'head_tab_4'); ?></a></li>
        <li><a href="#tabs-5">Recommended</a></li>
      </ul>
      
      <div id="tabs-1">
        
        <div class="ngaccordion">
          
          <h3>
		  	<?php 
			$head_tab_1 = cal_get_field($fields, 'head_tab_1');
			echo $head_tab_1;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Tab Title</label><?php echo cal_input_text('head_tab_1', '', $fields); ?></li>
            	
            	<li><label>Tab Image</label> <?php echo cal_input_upload('head_tab_img_1', 'images', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_give_birth = cal_get_field($fields, 'head_give_birth');
			echo $head_give_birth;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_give_birth', '', $fields); ?></li>
            	
            	<li><span>Options</span></li>
                <li><?php echo cal_input_text('give_birth_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('give_birth_2', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_birth_date = cal_get_field($fields, 'head_birth_date');
			echo $head_birth_date;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_birth_date', '', $fields); ?></li>
                
                <li><span>Options</span></li>
                <li><label>Month</label><?php echo cal_input_text('birth_month', '', $fields); ?></li>
                <li><label>Day</label><?php echo cal_input_text('birth_day', '', $fields); ?></li>
                <li><label>Year</label><?php echo cal_input_text('birth_year', '', $fields); ?></li>
                <li><label>Total Years</label><?php echo cal_input_number('birth_date', '', $fields); ?></li>
                <li><label>Under 8 Months Postpartum</label><?php echo cal_input_textarea('text_under_8_month', '', $fields); ?></li>
                <li><label>Over 8 Months Postpartum</label><?php echo cal_input_textarea('text_over_8_month', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_birth_by_csection = cal_get_field($fields, 'head_birth_by_csection');
			echo $head_birth_by_csection;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_birth_by_csection', '', $fields); ?></li>
            	
            	<li><span>Options</span></li>
                <li><?php echo cal_input_text('birth_by_csection_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('birth_by_csection_2', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_baby_pooch = cal_get_field($fields, 'head_baby_pooch');
			echo $head_baby_pooch;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_baby_pooch', '', $fields); ?></li>
            	
            	<li><span>Options</span></li>
                <li><?php echo cal_input_text('baby_pooch_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('baby_pooch_2', '', $fields); ?></li>
                <li><?php echo cal_input_text('baby_pooch_3', '', $fields); ?></li>
                <li><?php echo cal_input_text('baby_pooch_4', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_plan_on_csection = cal_get_field($fields, 'head_plan_on_csection');
			echo $head_plan_on_csection;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_plan_on_csection', '', $fields); ?></li>
            	
            	<li><span>Options</span></li>
                <li><?php echo cal_input_text('plan_on_csection_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('plan_on_csection_2', '', $fields); ?></li>
                <li><?php echo cal_input_text('plan_on_csection_3', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_how_many_week = cal_get_field($fields, 'head_how_many_week');
			echo $head_how_many_week;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_how_many_week', '', $fields); ?></li>
                
                <li><span>Options</span></li>
                <li><?php echo cal_input_text('measure_week_no', '', $fields); ?></li>
                
                <li><span>Message Text</span></li>
                <li><?php echo cal_input_textarea('text_measure_week', '', $fields); ?></li>
                <li><?php echo cal_input_text('measure_week_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('measure_week_2', '', $fields); ?></li>
            </ul>
          </div>
          
        </div>
        
      </div>
      <!-- / #tabs-1 -->
      
      <div id="tabs-2">
        
        <div class="ngaccordion">
          
          <h3>
		  	<?php 
			$head_tab_2 = cal_get_field($fields, 'head_tab_2');
			echo $head_tab_2;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Tab Title</label><?php echo cal_input_text('head_tab_2', '', $fields); ?></li>
            	
            	<li><label>Tab Image</label> <?php echo cal_input_upload('head_tab_img_2', 'images', $fields); ?></li>
            </ul>
          </div>
          
          <h3>Yes</h3>
          <div>
            <ul>
            	<li><span>Weight</span></li>
                <li><label>Pre-Pregnancy</label><?php echo cal_input_text('yes_pregnancy_weight', '', $fields); ?></li>
                <li><label>Heaviest Weight</label><?php echo cal_input_text('yes_heaviest_weight', '', $fields); ?></li>
                <li><label>Weight Now</label><?php echo cal_input_text('yes_weight_now', '', $fields); ?></li>
                
                <li><span>Calculation</span></li>
                <li><label>Pregnancy Gained</label><?php echo cal_input_text('yes_pregnancy_gained', '', $fields); ?></li>
                <li><label>After Birth</label><?php echo cal_input_text('yes_after_childbirth', '', $fields); ?></li>
                <li><label>Remaining Weight</label><?php echo cal_input_text('yes_remain_weight', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>No</h3>
          <div>
            <ul>
            	<li><span>Weight</span></li>
                <li><label>Pre-Pregnancy</label><?php echo cal_input_text('no_pregnancy_weight', '', $fields); ?></li>
                <li><label>Weight Now</label><?php echo cal_input_text('no_weight_now', '', $fields); ?></li>
                
                <li><span>Calculation</span></li>
                <li><label>Pregnancy Gained</label><?php echo cal_input_text('no_pregnancy_gained', '', $fields); ?></li>
            </ul>
          </div>
          
        </div>
        
      </div>
      <!-- / #tabs-2 -->
      
      <div id="tabs-3">
      
        <div class="ngaccordion">
          
          <h3>
		  	<?php 
			$head_tab_3 = cal_get_field($fields, 'head_tab_3');
			echo $head_tab_3;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Tab Title</label><?php echo cal_input_text('head_tab_3', '', $fields); ?></li>
            	
            	<li><label>Tab Image</label> <?php echo cal_input_upload('head_tab_img_3', 'images', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$tall_are_you = cal_get_field($fields, 'tall_are_you');
			echo $tall_are_you;
			?>
          </h3>
          <div>
            <ul>
            	<li><?php echo cal_input_text('tall_are_you', '', $fields); ?></li>
                <li><span>Options</span></li>
                <li><?php echo cal_input_text('tall_text', '', $fields); ?></li>
                <li><?php echo cal_input_text('tall_under', '', $fields); ?></li>
                <li><?php echo cal_input_text('tall_over', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_carry_your_weight = cal_get_field($fields, 'head_carry_your_weight');
			echo $head_carry_your_weight;
			?>
          </h3>
          <div>
            <ul>
            	<li><label><?php echo cal_input_text('head_carry_your_weight', '', $fields); ?></label></li>
            	
            	<li><span>Options</span></li>
                <li><label>(1)</label><?php echo cal_input_text('carry_your_weight_1', '', $fields); ?></li>
                <li><label>(2)</label><?php echo cal_input_text('carry_your_weight_2', '', $fields); ?></li>
                <li><label>(3)</label><?php echo cal_input_text('carry_your_weight_3', '', $fields); ?></li>
                <li><label>(4)</label><?php echo cal_input_text('carry_your_weight_4', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_body_shapes = cal_get_field($fields, 'head_body_shapes');
			echo $head_body_shapes;
			?>
          </h3>
          <div>
            <ul>
            	<li><label><?php echo cal_input_text('head_body_shapes', '', $fields); ?></label></li>
            	
            	<li>
                	<table width="0" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Text</th>
                      </tr>
                      <tr>
                        <td><?php echo cal_input_text('body_shape_name_1', 'Hourglass', $fields); ?></td>
                        <td><?php echo cal_input_textarea('body_shape_text_1', '', $fields); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo cal_input_text('body_shape_name_2', 'Triangle', $fields); ?></td>
                        <td><?php echo cal_input_textarea('body_shape_text_2', '', $fields); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo cal_input_text('body_shape_name_3', 'Oval', $fields); ?></td>
                        <td><?php echo cal_input_textarea('body_shape_text_3', '', $fields); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo cal_input_text('body_shape_name_4', 'Inverted-Triangle', $fields); ?></td>
                        <td><?php echo cal_input_textarea('body_shape_text_4', '', $fields); ?></td>
                      </tr>
                      <tr>
                        <td><?php echo cal_input_text('body_shape_name_5', 'Rectangle', $fields); ?></td>
                        <td><?php echo cal_input_textarea('body_shape_text_5', '', $fields); ?></td>
                      </tr>
                    </table>
                    
                    <br />
                    
                    <table width="0" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Active Images</th>
                        <th scope="col">Inactive Images</th>
                      </tr>
                      <tr>
                        <td>Hourglass</td>
                        <td><?php echo cal_input_upload('body_shapes_act_1', 'images/shapes', $fields); ?></td>
                        <td><?php echo cal_input_upload('body_shapes_in_1', 'images/shapes', $fields); ?></td>
                      </tr>
                      <tr>
                        <td>Triangle</td>
                        <td><?php echo cal_input_upload('body_shapes_act_2', 'images/shapes', $fields); ?></td>
                        <td><?php echo cal_input_upload('body_shapes_in_2', 'images/shapes', $fields); ?></td>
                      </tr>
                      <tr>
                        <td>Oval</td>
                        <td><?php echo cal_input_upload('body_shapes_act_3', 'images/shapes', $fields); ?></td>
                        <td><?php echo cal_input_upload('body_shapes_in_3', 'images/shapes', $fields); ?></td>
                      </tr>
                      <tr>
                        <td>Inverted-Triangle</td>
                        <td><?php echo cal_input_upload('body_shapes_act_4', 'images/shapes', $fields); ?></td>
                        <td><?php echo cal_input_upload('body_shapes_in_4', 'images/shapes', $fields); ?></td>
                      </tr>
                      <tr>
                        <td>Rectangle</td>
                        <td><?php echo cal_input_upload('body_shapes_act_5', 'images/shapes', $fields); ?></td>
                        <td><?php echo cal_input_upload('body_shapes_in_5', 'images/shapes', $fields); ?></td>
                      </tr>
                    </table>
                </li>
                
            </ul>
          </div>
          
        </div>
        
      </div>
      <!-- / #tabs-3 -->
      
      <div id="tabs-4">
      
        <div class="ngaccordion">
          
          <h3>
		  	<?php 
			$head_tab_4 = cal_get_field($fields, 'head_tab_4');
			echo $head_tab_4;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Tab Title</label><?php echo cal_input_text('head_tab_4', '', $fields); ?></li>
            	
            	<li><label>Tab Image</label> <?php echo cal_input_upload('head_tab_img_4', 'images', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$pregnancy_jean_size = cal_get_field($fields, 'pregnancy_jean_size');
			echo $pregnancy_jean_size;
			?>
          </h3>
          <div>
            <ul>
            	<li><?php echo cal_input_text('pregnancy_jean_size', '', $fields); ?></li>
                <li><label>Image</label> <?php echo cal_input_upload('jean_size_img', 'images', $fields); ?></li>
                <li><span>Options</span></li>
                <li><?php echo cal_input_text('jean_size_text', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_your_hip_contour = cal_get_field($fields, 'head_your_hip_contour');
			echo $head_your_hip_contour;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_your_hip_contour', '', $fields); ?></li>
            	
            	<li><span>Options</span></li>
                <li><?php echo cal_input_text('your_hip_contour_1', '', $fields); ?></li>
                <li><?php echo cal_input_text('your_hip_contour_2', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$measuring_inches = cal_get_field($fields, 'head_measuring_inches');
			echo $measuring_inches;
			?>
          </h3>
          <div>
            <ul>
            	<li><?php echo cal_input_text('head_measuring_inches', '', $fields); ?></li>
                <li><label>Text</label> <?php echo cal_input_text('measure_ddl_text', '', $fields); ?></li>
                <li><label>Image</label> <?php echo cal_input_upload('measuring_inches_img', 'images', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$printable_measure = cal_get_field($fields, 'head_printable_measure');
			echo $printable_measure;
			?>
          </h3>
          <div>
            <ul>
            	<li><?php echo cal_input_text('head_printable_measure', '', $fields); ?></li>
                <li><label>Link</label> <?php echo cal_input_text('printable_measure_pdf', '', $fields); ?></li>
                <li><label>Image</label> <?php echo cal_input_upload('printable_measure_img', 'images', $fields); ?></li>
                <li><label>Message Text</label> <?php echo cal_input_textarea('printable_msg_text', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_measure_video = cal_get_field($fields, 'head_measure_video');
			echo $head_measure_video;
			?>
          </h3>
          <div>
            <ul>
            	<li><?php echo cal_input_text('head_measure_video', '', $fields); ?></li>
                <li><label>Video Link</label> <?php echo cal_input_text('measure_video_link', '', $fields); ?></li>
            </ul>
          </div>
          
        </div>
        
      </div>
      <!-- / #tabs-4 -->
      
      <div id="tabs-5">
      
        <div class="ngaccordion">
          
          <h3>Messages</h3>
          <div>
            <ul>
            	<li><label>Under 36 Weeks</label><?php echo cal_input_textarea('msg_under_36_week', '', $fields); ?></li>
                <li><label>No Hip Contour</label><?php echo cal_input_textarea('msg_no_hip_contour', '', $fields); ?></li>
                <li><label>Call for Sizing</label><?php echo cal_input_textarea('msg_call_for_size', '', $fields); ?></li>
                <li><label>Email Reminder Yes</label><?php echo cal_input_textarea('msg_email_yes', '', $fields); ?></li>
                <li><label>Email Reminder No</label><?php echo cal_input_textarea('msg_email_no', '', $fields); ?></li>
                <li><label>Red Box Alert</label><?php echo cal_input_textarea('msg_alert_box', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_recommended_size = cal_get_field($fields, 'head_recommended_size');
			echo $head_recommended_size;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Tab Title</label><?php echo cal_input_text('head_recommended_size', '', $fields); ?></li>
            	<?php /*?><li><label>Tab Image</label> <?php echo cal_input_upload('head_tab_img_4', 'images', $fields); ?></li><?php */?>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_recommended_style = cal_get_field($fields, 'head_recommended_style');
			echo $head_recommended_style;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_recommended_style', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_recommended_bundle = cal_get_field($fields, 'head_recommended_bundle');
			echo $head_recommended_bundle;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_recommended_bundle', '', $fields); ?></li>
            </ul>
          </div>
          
          <h3>
		  	<?php 
			$head_additional_option = cal_get_field($fields, 'head_additional_option');
			echo $head_additional_option;
			?>
          </h3>
          <div>
            <ul>
            	<li><label>Title</label><?php echo cal_input_text('head_additional_option', '', $fields); ?></li>
                <li><label>Checkbox Text</label><?php echo cal_input_text('head_need_to_speak', '', $fields); ?></li>
                <li><label>Email Button</label><?php echo cal_input_text('head_email_button', '', $fields); ?></li>
            </ul>
          </div>
          
        </div>
        
      </div>
      <!-- / #tabs-5 -->
      
    </div>
    <br />
    <button name="submit" class="button">Save / Update</button>
</form>

<script type="text/javascript">
jQuery(function() {
	jQuery( "#ngtabs" ).tabs();
	jQuery( ".ngaccordion" ).accordion({
      heightStyle: "content"
    });
});
</script>