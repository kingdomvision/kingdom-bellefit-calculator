<div class="wrap">
	<h1>Order Calculation Form Details</h1>
    <?php global $wpdb; ?>
    <?php if (isset($_GET['action']) && $_GET['action'] == 'view') { ?>
    
        <?php
		if (isset($_GET['calkey'])) {
			$calkey = $_GET['calkey'];
			$forms_data = $wpdb->get_results(" SELECT * FROM cal_form_order_data WHERE cal_id = '$calkey' LIMIT 0,1 ");
		} 
	    foreach($forms_data as $data) {
            ?>
            <div class="form_details">
                <div class="form_details_head">
                    ID : 
                </div>
                <div class="form_details_value">
                    <?php echo $data->cal_id; ?>
                </div>
            </div>
            <div class="form_details">
                <div class="form_details_head">
                    Date : 
                </div>
                <div class="form_details_value">
                    <?php $date = 'date'; echo date("F, d Y h:i:s", strtotime($data->$date)); ?>
                </div>
            </div>
            <?php
            $cal_value = $data->cal_data;
            $cal_value = unserialize($cal_value);
			
			$reorder_cal_value = array();
			
			if (isset($cal_value->give_birth)) {
				$reorder_cal_value['Did already give birth'] = $cal_value->give_birth;
			}
			
			if (isset($cal_value->give_birth_date)) {
				$reorder_cal_value['When did give birth'] = $cal_value->give_birth_date;
			} else if ( isset($cal_value->give_birth_month) && isset($cal_value->give_birth_day) && isset($cal_value->give_birth_year) ) { 
				$reorder_cal_value['When did give birth'] = $cal_value->give_birth_month.'-'.$cal_value->give_birth_day.'-'.$cal_value->give_birth_year; 
			}
			
			if (isset($cal_value->birth_by_csection)) {
				$reorder_cal_value['Did give birth by C-Section'] = $cal_value->birth_by_csection;
			}
			
			if (isset($cal_value->plan_on_csection)) {
				$reorder_cal_value['Plan on having a C-Section'] = $cal_value->plan_on_csection;
			}
			
			if (isset($cal_value->how_many_week)) {
				$reorder_cal_value['Pre-Pregnancy Weight, weeks'] = $cal_value->how_many_week;
			}
			
			if (isset($cal_value->measure_week)) {
				$reorder_cal_value['Receive a Sizing Reminder'] = $cal_value->measure_week;
			}
			
			if (isset($cal_value->week_email)) {
				$reorder_cal_value['Email'] = $cal_value->week_email;
			}
			
			if (isset($cal_value->postpartum_swelling)) {
				$reorder_cal_value['Post-Baby Pooch Swelling'] = $cal_value->postpartum_swelling;
			}
			
			if (isset($cal_value->_2_pregnancy_weight)) {
				$reorder_cal_value['Pre-Pregnancy Weight'] = $cal_value->_2_pregnancy_weight . ' Lb';
			}
			
			if (isset($cal_value->_2_heaviest_weight)) {
				$reorder_cal_value['Weight Just Before Gave Birth'] = $cal_value->_2_heaviest_weight . ' Lb';
			}
			
			if (isset($cal_value->_2_weight_now)) {
				$reorder_cal_value['Weight Now'] = $cal_value->_2_weight_now . ' Lb';
			}
			
			if (isset($cal_value->pregnancy_gained)) {
				$reorder_cal_value['During Pregnance Gaines'] = $cal_value->pregnancy_gained . ' Lb';
			}
			
			if (isset($cal_value->after_childbirth)) {
				$reorder_cal_value['From Giving Birth Until Now, Lost'] = $cal_value->after_childbirth . ' Lb';
			}
			
			if (isset($cal_value->remain_weight)) {
				$reorder_cal_value['Remaining Weight Left to Lose'] = $cal_value->remain_weight . ' Lb';
			}
			
			if (isset($cal_value->tall_are_you)) {
				$reorder_cal_value['How Tall'] = $cal_value->tall_are_you;
			}
			
			if (isset($cal_value->carry_your_weight)) {
				$reorder_cal_value['Where do tend to carry weight'] = $cal_value->carry_your_weight;
			}
			
			if (isset($cal_value->body_shapes)) {
				$reorder_cal_value['Body Shapes'] = $cal_value->body_shapes;
			}
			
			if (isset($cal_value->pregnancy_jean_size)) {
				$reorder_cal_value['Pre-Pregnancy Jean Size'] = $cal_value->pregnancy_jean_size;
			}
			
			if (isset($cal_value->your_hip_contour)) {
				$reorder_cal_value['Measure Hip Contour'] = $cal_value->your_hip_contour;
			}
			
			if (isset($cal_value->measuring_inches)) {
				$reorder_cal_value['Hip Measurement in Inches'] = $cal_value->measuring_inches;
			}
			
            foreach ($reorder_cal_value as $key => $value) {
                ?>
                <div class="form_details">
                    <div class="form_details_head">
                    	<?php echo $key . ' :'; ?>
                    </div>
                    <div class="form_details_value">
                        <?php echo $value; ?>
                    </div>
                </div>
                <?php
            }
        }
        ?>

    <?php } ?>
</div>