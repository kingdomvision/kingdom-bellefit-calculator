<?php
$message = '';
$error = 0;
if (isset($_POST['bellefit_video_link_submit'])) {
	
	if (!empty($_FILES["bellefit_form_size_csv_file"]['name'])) {
		
		$uploadFileSize = basename($_FILES["bellefit_form_size_csv_file"]["name"]);
		$target_dir = Cal_URI . '/includes/';
		$target_file_size = $target_dir . $uploadFileSize;
		$FileTypeSize = pathinfo($target_file_size, PATHINFO_EXTENSION);
		
		if ($uploadFileSize != 'SIZE.csv') {
			$error = 1;
			$message = '<p class="error"><strong>Error! </strong>Invalid File Name, SIZE.csv name allow.</p>';
		}
		
		if ($FileTypeSize != 'csv') {
			$error = 1;
			$message = '<p class="error"><strong>Error! </strong>Invalid File Type, only .csv format allow.</p>';
		}
		
		if (!$error) {
			if (!move_uploaded_file($_FILES["bellefit_form_size_csv_file"]["tmp_name"], $target_file_size)) {
				$error = 1;
				$message = '<p class="error"><strong>Error! </strong>Invalid SIZE.csv File, not uploaded.</p>';
			} 
		}
		
	}
	if (!empty($_FILES["bellefit_form_style_csv_file"]['name'])) {
		
		$uploadFileStyle = basename($_FILES["bellefit_form_style_csv_file"]["name"]);
		$target_dir = Cal_URI . '/includes/';
		$target_file_style = $target_dir . $uploadFileStyle;
		$FileTypeStyle = pathinfo($target_file_style, PATHINFO_EXTENSION);
		
		if ($uploadFileStyle != 'STYLE.csv') {
			$error = 1;
			$message = '<p class="error"><strong>Error! </strong>Invalid File Name, STYLE.csv name allow.</p>';
		}
		
		if ($FileTypeStyle != 'csv') {
			$error = 1;
			$message = '<p class="error"><strong>Error! </strong>Invalid File Type, only .csv format allow.</p>';
		}
		
		if (!$error) {
			if (!move_uploaded_file($_FILES["bellefit_form_style_csv_file"]["tmp_name"], $target_file_style)) {
				$error = 1;
				$message = '<p class="error"><strong>Error! </strong>Invalid STYLE.csv File, not uploaded.</p>';
			}
			
		}
		
	}
		
	$form_page_id = $_POST['bellefit_form_page_id'];
	$video_link = $_POST['bellefit_form_video_link'];
	$mailchimp_api_key = $_POST['bellefit_mailchimp_api'];
	$mailchimp_list = $_POST['bellefit_mailchimp_list'];
	$mailchimp_optin = $_POST['bellefit_mailchimp_optin'];
	$mailchimp_segment = $_POST['bellefit_mailchimp_group'];
	$thirdparty_server = $_POST['bellefit_thirdparty_server'];
	$thirdparty_database = $_POST['bellefit_thirdparty_database'];
	$thirdparty_username = $_POST['bellefit_thirdparty_username'];
	$thirdparty_password = $_POST['bellefit_thirdparty_password'];
	$bellefit_custom_css = $_POST['bellefit_custom_css'];
	if ($video_link != '') {
		if (filter_var($video_link, FILTER_VALIDATE_URL) === false) {
			$error = 1;
			$message = '<p class="error"><strong>Error! </strong>Invalid Video URL</p>';
		}
	}
	if (!$error) {
		$message = '<p class="success"><strong>Success! </strong>Settings Updated.</p>';
		update_option('_bellefit_form_video_link', $video_link);
		update_option('_bellefit_form_page_id', $form_page_id);
		update_option('_bellefit_mailchimp_api', $mailchimp_api_key);
		update_option('_bellefit_mailchimp_list', $mailchimp_list);
		update_option('_bellefit_mailchimp_optin', $mailchimp_optin);
		update_option('_bellefit_mailchimp_segment', $mailchimp_segment);
		update_option('_bellefit_thirdparty_server', $thirdparty_server);
		update_option('_bellefit_thirdparty_database', $thirdparty_database);
		update_option('_bellefit_thirdparty_username', $thirdparty_username);
		update_option('_bellefit_thirdparty_password', $thirdparty_password);
		update_option('_bellefit_custom_css', $bellefit_custom_css);
	}
	
}
?>

<div class="wrap">
	<h1>Form Settings</h1>
    <?php
	if ($message) echo $message;
	?>
    <form method="post" action="" enctype="multipart/form-data" >
    	<div class="form-group form_details">
        	<div class="form_details_head">
                <label>Upload CSV Files</label>
                <?php if ( file_exists( Cal_URI . '/includes/SIZE.csv') ) {
                    echo '<p>SIZE.csv <a href="'. Cal_URL .'/includes/SIZE.csv">Download</a></p>';
                } else {
                    echo '<p>SIZE.csv Not Found! please upload.</p>';
                } ?>
            </div>
            <div class="form_details_value">
            	<input type="file" name="bellefit_form_size_csv_file" id="bellefit-form-size-csv-file" />
            </div>
        </div>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
                <?php if ( file_exists( Cal_URI . '/includes/STYLE.csv') ) {
                    echo '<p>STYLE.csv <a href="'. Cal_URL .'/includes/STYLE.csv">Download</a></p>';
                } else {
                    echo '<p>STYLE.csv Not Found! please upload.</p>';
                }?>
            </div>
            <div class="form_details_value">
            	<input type="file" name="bellefit_form_style_csv_file" id="bellefit-form-style-csv-file" />
            </div>
        </div>
        <br /><br />
        
        <h1>Mailchimp Settings</h1>
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Mailchimp API Key</label>
            </div>
            <div class="form_details_value">
	            <input type="text" name="bellefit_mailchimp_api" id="bellefit-mailchimp-api" value="<?php echo get_option('_bellefit_mailchimp_api'); ?>" />
            </div>
        </div>
        <?php
		use \DrewM\MailChimp\MailChimp;
        $mailchimp_api_key = get_option('_bellefit_mailchimp_api');
		$mailchimp_list = get_option('_bellefit_mailchimp_list');
		if ($mailchimp_api_key != '') {
			require_once 'mailchimp/MCAPI.class.php';
			$api = new MCAPI($mailchimp_api_key);
			$subscriber_lists = $api->lists();
		}
        ?>
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Select Subscriber List</label>
            </div>
            <div class="form_details_value">
	            <select name="bellefit_mailchimp_list" id="bellefit-mailchimp-list">
                	<option value="">Select Subscriber List</option>
                    <?php
					if (!empty($subscriber_lists)) {
						foreach($subscriber_lists['data'] as $list) {
							if ($list['id'] == $mailchimp_list) {
								$selected = 'selected="selected"';
							} else {
								$selected = '';
							}
							?><option <?php echo $selected; ?> value="<?php echo $list['id']; ?>"><?php echo $list['name']; ?></option><?php
						}
					}
					?>
                </select>
            </div>
        </div>
        
        <?php if ($mailchimp_api_key != '' && $mailchimp_list != '') {
			$mailchimp_segment = get_option('_bellefit_mailchimp_segment');
			include( 'mailchimp/src/MailChimp.php' );
			$MailChimp = new MailChimp($mailchimp_api_key);
			
			$subscriber_group_list = $MailChimp->get("lists/$mailchimp_list/segments");
			$id = $subscriber_group_list['id'];
			$segments = $subscriber_group_list['segments'];
			
		?>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Disable Double Opt-in</label>
            </div>
            <div class="form_details_value">
            	<input type="checkbox" name="bellefit_mailchimp_optin" id="bellefit-mailchimp-optin" <?php if (get_option('_bellefit_mailchimp_optin')) echo "checked"; ?> />
            </div>
        </div>    
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Select Group for Subscriber</label>
            </div>
            <div class="form_details_value">
	            <select name="bellefit_mailchimp_group" id="bellefit-mailchimp-group">
                	<option value="">Select Group List</option>
                    <?php
					if (!empty($segments)) {
						foreach($segments as $segment) {
							if ($segment['id'] == $mailchimp_segment) {
								$selected = 'selected="selected"';
							} else {
								$selected = '';
							}
							?><option <?php echo $selected; ?> value="<?php echo $segment['id']; ?>"><?php echo $segment['name']; ?></option><?php
						}
					}
					?>
                </select>
            </div>
        </div>
        <?php } ?>
        <br /><br />
        
        <h1>Third Party database</h1>
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Host Name</label>
            </div>
            <div class="form_details_value">
	            <input required type="text" name="bellefit_thirdparty_server" id="bellefit-thirdparty-server" value="<?php echo get_option('_bellefit_thirdparty_server'); ?>" />
            </div>
        </div>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Database Name</label>
            </div>
            <div class="form_details_value">
	            <input required type="text" name="bellefit_thirdparty_database" id="bellefit-thirdparty-database" value="<?php echo get_option('_bellefit_thirdparty_database'); ?>" />
            </div>
        </div>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Username</label>
            </div>
            <div class="form_details_value">
	            <input required type="text" name="bellefit_thirdparty_username" id="bellefit-thirdparty-username" value="<?php echo get_option('_bellefit_thirdparty_username'); ?>" />
            </div>
        </div>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Password</label>
            </div>
            <div class="form_details_value">
	            <input required type="password" name="bellefit_thirdparty_password" id="bellefit-thirdparty-password" value="<?php echo get_option('_bellefit_thirdparty_password'); ?>" />
            </div>
        </div>
        
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Connection Status</label>
            </div>
            <div class="form_details_value">
	        	<?php 
					$ex_wpdb = external_wpdb();
					//echo $ex_wpdb->print_error();
					/*
					echo "<pre>";
					print_r($ex_wpdb);
					echo "</pre>";*/
					
					if($ex_wpdb->error)
						echo "Connection Failed";
					else
						echo "Connected Successfully";
				?>  
            </div>
        </div>
        <br />
        <h1>CSS Option</h1>
        <div class="form-group form_details">
        	<div class="form_details_head">
	        	<label>Apply Custom CSS</label>
            </div>
            <div class="form_details_value" style="width: 70%;">
				<textarea name="bellefit_custom_css" id="bellefit-custom-css" style="height:400px; width:95%"><?php echo get_option('_bellefit_custom_css'); ?></textarea>    		
        	</div>
        </div>
        
        <div class="form-group">
        	<div class="form_details_head">
    	        <input type="submit" name="bellefit_video_link_submit" value="Submit" id="bellefit-video-link-submit" />
            </div>
            <div class="form_details_value">
        	    &nbsp;
            </div>
        </div>
    </form>
</div>