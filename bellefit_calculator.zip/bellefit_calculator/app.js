var calApp = angular.module('calculatorApp', ['ngSanitize', 'ngCookies', 'ng.deviceDetector'])
// Main Controller
.controller('MainCtrl', ['$scope', '$http', '$location', '$anchorScroll', 'deviceDetector', '$cookieStore', function($scope, $http, $location, $anchorScroll, deviceDetector, $cookieStore) {
	
	/* 
		Create Variable / Scope / Objects
	*/
	
	$scope.device_data = deviceDetector;
	$scope.hashSteps = 0;
	$scope.items = [];
	$scope.date = new Date();
	$scope.regexValid = {
					"email": "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",
					"number" : "\\d+"
				};
				
	$scope.cal = {};
	$scope.full_step = false;
	$scope.goBack = '';
	
	var cal = {};
	var cookie_name = "calculate";
	
	if( $cookieStore.get(cookie_name) != null ) {
		cal = $cookieStore.get(cookie_name);
	}
	
	cal.uniqid = numGenerated();
	$scope.cal = cal;
	$scope.stepsInfo = [
						'Childbirth &amp; Delivery Method',
						'Your Weight',
						'Body Shape',
						'Your Size'
					   ];
	
/* ****************************************** */
	
	/* 
		Create Functions
	*/
	
	function numGenerated() {
		var number = Math.random();
		number.toString(36);
		var id = number.toString(36).substr(2, 10);
		return id;
	}
	
	$scope.subTotal = function(value1, value2) {
		return (value1 == null || value2 == null)? 0 : (parseInt(value1) - parseInt(value2));
	}
	
	$scope.dropdown_number = function(start, end) {
		var i = parseInt(start);
		var total = parseInt(end);
		var values = Array();
		for(i; i <= total; i++) {
			values.push(i);
		}
		
		return values;
	}
	
	$scope.range_number = function(start, end){
		var i = parseInt(start);
		var total = parseInt(end);
		var values = Array();
		for(i; i <= total; i++) {
			var val = i + '-' + (i+1);
			values.push(val);
		}
		
		return values;
	}
	
	$scope.point_number = function(start, end){
		var i = parseFloat(start);
		var total = parseFloat(end);
		var values = Array();
		for(i; i <= total; i= i + 0.5) {
			values.push(i.toFixed(1));
		}
		return values;
	}
	
	$scope.getImage = function(image) {
		return calUrl + '/images/' + image;
	}
	
	function loadHash() {
		var getHashVal = window.location.hash.substr(1);
		getHashVal = getHashVal.replace("#step", "");
		return parseInt(getHashVal);
	}
	
	function stepScroll(stepNo) {
		$location.hash(stepNo);
		$anchorScroll();
	}
	
	$scope.goNext = function(i) {
		
		$scope.cal.nextSteps = i;
		stepScroll('step'+i);
		
		if( $scope.cal.nextSteps < 4 ) {
			$scope.cal.prevSteps = i;
		}
		
		return false;
	}
	
	$scope.$on("$locationChangeSuccess", function (event) {
    	$scope.isAllSteps($scope.cal);
		
		var changeHashStep = loadHash();
		var formStep = $scope.hashSteps;
		
		if( ( changeHashStep <= formStep || changeHashStep === 5 || changeHashStep == 0) && changeHashStep != '' ) {
			$scope.goNext( changeHashStep );
		}
		else if( changeHashStep == '0' || changeHashStep == 0 ) {
			$scope.goNext( changeHashStep );
		}
		
	});
	
	$scope.runProgress = function(step) {
		var step = step ? (step+1) : 1;
		var percent = (parseInt(step) / 4) * 100;
		return percent + '%';
	}
	
	$scope.cal_remain_weight_gain = function(data){
		data.pregnancy_gained = $scope.subTotal(data._2_heaviest_weight, data._2_pregnancy_weight);
		data.after_childbirth = $scope.subTotal(data._2_heaviest_weight, data._2_weight_now);
		data.remain_weight = $scope.subTotal(data.pregnancy_gained, data.after_childbirth);
		
    };
	
	$scope.cal_weight_gain_pregnant = function(data){
		data.weight_gain_pregnant = $scope.subTotal(data.weight_now_no, data.pregnancy_weight_no);
    };
	
	$scope.cal_givebirth = function(data) {
		return $scope.cal = {uniqid: data.uniqid, nextSteps: false, prevSteps: false, give_birth: data.give_birth}
    };
	
	$scope.reset_calculation = function() {
		$cookieStore.remove(cookie_name);
		$scope.hashSteps = 0;
		return $scope.cal = {uniqid: numGenerated()}
    };
	
	$scope.er_valid = function(data) {
		if( data.need_to_speak ) {
			if( data.phone == '' && data.fullname == '' )
				return false;
		}
		
		return true;
    };
	
	$scope.monthDiff = function(data) {
		var date2 = new Date();
		var date1 = new Date(data.give_birth_year, data.give_birth_month, data.give_birth_day );
		var timeDiff = Math.abs(date2.getTime() - date1.getTime());
		return Math.ceil(timeDiff / (1000 * 3600 * 24) / 30);
	}
	
	
/* ****************************************** */
	
	/* 
		Create Filters
	*/
	
	$scope.daysInMonth = function(m, y) {
		switch (m) {
			case 1 :
				return function(data){
					var curYear = $scope.date.getUTCFullYear();
					y = (y == null) ? curYear : y;
					var feb = (y % 4 == 0 && y % 100) || y % 400 == 0 ? 29 : 28;
					if (data <= feb) return true;
				}
			case 8 : case 3 : case 5 : case 10 :
				return function(data){
					if (data <= 30) return true;
				}
			default :
				return function(data){
					if (data <= 31) return true;
				}
		}
	}
	
	$scope.get_device = function() {
		if($scope.device_data.device === 'unknown') // desktop
			return 'select-desktop';
			
		return 'select-mobile';
	}
	
	$scope.ddl_change = function() {
		if($scope.get_device() == 'select-desktop') {
			jQuery('.ddl-active select').select2({
				dropdownAutoWidth: true,
				width: 'style',
				minimumResultsForSearch: 'Infinity'
			});
		}
	}
	
	$scope.custom_options = function(val1, val2) {
		$scope.items = [];
		var itemList1 = {val: 'under-5-7', name: val1 };
		var itemList2 = {val: 'over-5-7', name: val2 };
		
		$scope.items.push(itemList1);
		$scope.items.push(itemList2);
	}
	
	$scope.greaterThan = function(val){
		return function(data){
			if (data > val) return true;
		}
	}
	
	$scope.lessThan = function(val){
		return function(data){
			if (data < val) return true;
		}
	}
	
/* ****************************************** */
	/* 
		Create Conditions
	*/
	
	$scope.isSteps = function(steps, data){
		var step = false;
		if( steps == 'step2_a' && (data.how_many_week > 35 || data.postpartum_swelling) ) {
			step = true;
		}
		else if( steps == 'step2_b' ) {
			if( data.how_many_week < 36 ) 
				if( (data.week_email != null && data.measure_week == 'Yes') || data.measure_week == 'No' )
					step = true;
					
		}
		else if( steps == 'step3' && ( $scope.isSteps('step2_b', data) || ( (data.pregnancy_gained > data.after_childbirth && data.pregnancy_gained > data.remain_weight) || (data.weight_gain_pregnant > 0)) ) ) {
			step = true;
		}
		else if( steps == 'step4' && (data.tall_are_you && data.carry_your_weight && data.body_shapes) ) {
			step = true;
		}
		else if( steps == 'step5' && (data.pregnancy_jean_size != null) && ( (data.your_hip_contour == 'Yes' && data.measuring_inches) || (data.your_hip_contour == 'No') ) ) {
			step = true;
		}
		return step;
	}
	
	$scope.isAllSteps = function(data){
		var step = false;
		if( ($scope.isSteps('step2_a', data) || $scope.isSteps('step2_b', data)) ) {
			$scope.hashSteps = 1;
			if( $scope.isSteps('step2_b', data) || $scope.isSteps('step3', data) ) {
				$scope.hashSteps = 2;
				if( $scope.isSteps('step4', data) ) {
					$scope.hashSteps = 3;
					if( $scope.isSteps('step2_b', data) || $scope.isSteps('step5', data) ) {
						$scope.hashSteps = 4;
						step = true;
					}
				}
			}
		}
		return step;
	}
	
/* ****************************************** */
	
	
	$scope.getData = function(id){
		var data = {};
		data.id = id;
		
		$http.post(calUrl +'/includes/request.php', data).
		success(function(res, status, headers, config) {
			
			if(res.status == 'success')
				$scope.cal = res.cookie;
				
		}).
		error(function(res, status, headers, config) {
			$scope.returnMsg = 'Data send error.';
		});
	};
	
	$scope.dataSubmit = function(data){
		data.model = 'step';
		
		// Put cookies
		$cookieStore.put(cookie_name, data);
		
		// Get cookie
		var calculateCookie = $cookieStore.get(cookie_name);
  
		$http.post(calUrl +'/includes/recommendation.php', data).
		success(function(res, status, headers, config) {
			stepScroll('step4');
			window.scrollTo(0, 0);
			
			$scope.rec_size = res.size;
			$scope.rec_styles = angular.fromJson(res.style);
			$scope.rec_bundles = angular.fromJson(res.bundle);
			
			
		}).
		error(function(res, status, headers, config) {
			$scope.returnMsg = 'Data send error.';
		});
	};
	
	$scope.resultSubscribe = function(data){
		$http.post(calUrl +'/includes/email-subscribe.php', data).
		success(function(res, status, headers, config) {
			if( res.status = 'success' )
				$scope.subscribe = res.status;
				
		}).
		error(function(res, status, headers, config) {
			$scope.returnMsg = 'Data send error.';
		});
	};
	
	$scope.resultSubmit = function(data){
		$http.post(calUrl +'/includes/email_results.php', data).
		success(function(res, status, headers, config) {
			if( res.status = 'success' ) {
				$scope.res_result = res;
			}
		}).
		error(function(res, status, headers, config) {
			$scope.returnMsg = 'Data send error.';
		});
	};
	
	$scope.dataSave = function(data, action){
		data.model = 'save';
		data.action = action;
  
		$http.post(calUrl +'/includes/recommendation.php', data).
		success(function(res, status, headers, config) {
			if( res.status = 'success' && action == 'email' ) {
				$scope.res_save.status = res.status;
				$scope.res_save.action = action;
				data.save_email = '';
			}
		}).
		error(function(res, status, headers, config) {
			$scope.returnMsg = 'Data send error.';
		});
	};
}])
/* 
	Create Directive
*/
.directive('strInt', function() {
	return {
		priority: 1,
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, element, attr, ngModel) {
				function toModel(value) {
					return "" + value; // convert to string
				}
			
				function toView(value) {
					return parseInt(value); // convert to number
				}
				
				ngModel.$formatters.push(toView);
				ngModel.$parsers.push(toModel);
			  }
	}
});