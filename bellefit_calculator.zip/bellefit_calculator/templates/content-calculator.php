<?php 
	$cookie_token = $_GET['token'];
	if( ! empty($cookie_token) && strlen($cookie_token) == 10 )
		$cookie_data = sprintf('<div data-ng-init="getData(%s)"></div>', "'".$cookie_token."'");
		
	function cal_get_field($object, $key) {
		$field = $object->$key;
		if( !empty($field) ) {
			$field_decode = (htmlspecialchars_decode(wp_kses_decode_entities( stripslashes_deep($field) )));
			return $field_decode;
		}
		
		return '';
	}
	
	function cal_form_setting() {
		$form_setting = get_option( 'cal_form_setting' );
		$fields = json_decode($form_setting);
		return $fields;
	}
	$fields = cal_form_setting();
?>
<div class="container-calc" id="myWizard" ng-app="calculatorApp" ng-controller="MainCtrl">
<?php echo $cookie_data; ?>

  <form name="frmCal">
    <div class="main-step" ng-if="cal.nextSteps < 4 || !cal.nextSteps">
      
      <div class="tab-content" ng-switch="cal.nextSteps">
        <div id="step0" class="tab-pane fade in active" ng-switch-default>
          <div class="tab-head"> 
          <div class="tab-head-img"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'head_tab_img_1'); ?>')}}" /></div>
          <span><?php echo cal_get_field($fields, 'head_tab_1'); ?></span>
          <div class="progress-bar-container">
            <div class="progress">
              <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="5" ng-style="{'width':runProgress(cal.nextSteps)}"></div>
            </div>
          </div>
          </div>
          
          <div class="well">
            <ul class="steps">
              <li>
                <label><?php echo cal_get_field($fields, 'head_give_birth'); ?></label>
                <ul class="field-box ul-inline">
                  <li class="first">
                    <input type="radio" name="_1_give_birth" value="Yes" id="_1_give_birth_1" class="field-yes" ng-model="cal.give_birth" ng-change="cal_givebirth(cal)">
                    <label for="_1_give_birth_1"><span></span><?php echo cal_get_field($fields, 'give_birth_1'); ?></label>
                  </li>
                  <li class="second">
                    <input type="radio" name="_1_give_birth" value="No" id="_1_give_birth_0" class="field-no" ng-model="cal.give_birth" ng-change="cal_givebirth(cal)">
                    <label for="_1_give_birth_0"><span></span><?php echo cal_get_field($fields, 'give_birth_2'); ?></label>
                  </li>
                </ul>
              </li>
              <!-- / main li -->
              
              <div ng-if="cal.give_birth == 'Yes'" ng-init="ddl_change()">
                
                    <li class="message-box ddl-active">
                    
                      <div class="field-left">
                      <label for="_1_give_birth_date"><?php echo cal_get_field($fields, 'head_birth_date'); ?></label>
                      <ul class="field-box date-row">
                        <li>
                          <div class="dropdown-box">
                            <div ng-class="get_device()">
                            	<select name="_1_month" data-placeholder="<?php echo cal_get_field($fields, 'birth_month'); ?>" ng-model="cal.give_birth_month" ng-options="index for index in dropdown_number(1, 12)">
                                	<option value=""><?php echo cal_get_field($fields, 'birth_month'); ?></option>
                                </select>
                            </div>
                          </div>
                          
                          <div class="dropdown-box">
                            <div ng-class="get_device()">
                            	<select name="_1_day" data-placeholder="<?php echo cal_get_field($fields, 'birth_day'); ?>" ng-model="cal.give_birth_day" ng-options="index for index in dropdown_number(1, 31) | filter: daysInMonth(cal.give_birth_month -1, cal.give_birth_year)">
                                	<option value=""><?php echo cal_get_field($fields, 'birth_day'); ?></option>
                                </select>
                            </div>
                          </div>
                          
                          <div class="dropdown-box">
                            <div ng-class="get_device()">
                            	<?php 
                                $total_years = cal_get_field($fields, 'birth_date');
                                $total_years = ($total_years) ? $total_years : 5;
                                ?>
                                <select name="_1_year" data-placeholder="<?php echo cal_get_field($fields, 'birth_year'); ?>" ng-model="cal.give_birth_year" ng-options="index for index in dropdown_number((date.getFullYear()-<?php echo $total_years; ?>), date.getFullYear())">
                                	<option value=""><?php echo cal_get_field($fields, 'birth_year'); ?></option>
                                </select>
                            </div>
                          </div>
                          
                        </li>
                      </ul>
                      </div>                      
                      <div class="field-right" ng-if="(monthDiff(cal) > 8) || (monthDiff(cal) < 8)">
                          <div ng-if="monthDiff(cal) > 8">
                              <p><?php echo cal_get_field($fields, 'text_over_8_month'); ?></p>
                          </div>
                          
                          <div ng-if="monthDiff(cal) < 8">
                              <p><?php echo cal_get_field($fields, 'text_under_8_month'); ?></p>
                          </div>
                      </div>
                    </li>
                    <!-- / main li -->
                    
                    <li ng-if="cal.give_birth_month != null && cal.give_birth_day != null && cal.give_birth_year != null">
                      <label><?php echo cal_get_field($fields, 'head_birth_by_csection'); ?></label>
                      <ul class="field-box ul-inline">
                        <li class="first">
                          <input type="radio" name="_1_birth_by_csection" value="Yes" id="_1_birth_by_csection_1" ng-model="cal.birth_by_csection">
                          <label for="_1_birth_by_csection_1"><span></span><?php echo cal_get_field($fields, 'birth_by_csection_1'); ?></label>
                        </li>
                        <li class="second">
                          <input type="radio" name="_1_birth_by_csection" value="No" id="_1_birth_by_csection_0" ng-model="cal.birth_by_csection">
                          <label for="_1_birth_by_csection_0"><span></span><?php echo cal_get_field($fields, 'birth_by_csection_2'); ?></label>
                        </li>
                      </ul>
                    </li>
                    <!-- / main li -->
                    
                    <li ng-if="cal.birth_by_csection != null">
                      <label><?php echo cal_get_field($fields, 'head_baby_pooch'); ?></label>
                      <ul class="field-box">
                        <li class="first">
                          <input type="radio" name="_1_baby_pooch" value="very-swollen" id="_1_baby_pooch_1" ng-model="cal.postpartum_swelling">
                          <label for="_1_baby_pooch_1"><span></span><?php echo cal_get_field($fields, 'baby_pooch_1'); ?></label>
                        </li>
                        <li class="second">
                          <input type="radio" name="_1_baby_pooch" value="pretty-swollen" id="_1_baby_pooch_2" ng-model="cal.postpartum_swelling">
                          <label for="_1_baby_pooch_2"><span></span><?php echo cal_get_field($fields, 'baby_pooch_2'); ?></label>
                        </li>
                        <li class="third">
                          <input type="radio" name="_1_baby_pooch" value="slightly-swollen" id="_1_baby_pooch_3" ng-model="cal.postpartum_swelling">
                          <label for="_1_baby_pooch_3"><span></span><?php echo cal_get_field($fields, 'baby_pooch_3'); ?></label>
                        </li>
                        <li class="fourth">
                          <input type="radio" name="_1_baby_pooch" value="no-swelling" id="_1_baby_pooch_4" ng-model="cal.postpartum_swelling">
                          <label for="_1_baby_pooch_4"><span></span><?php echo cal_get_field($fields, 'baby_pooch_4'); ?></label>
                        </li>
                      </ul>
                    </li>
                    <!-- / main li -->
                
              </div>
              <!-- / .active-yes -->
              
              <div ng-if="cal.give_birth == 'No'">
			  
                <li>
                  <label><?php echo cal_get_field($fields, 'head_plan_on_csection'); ?></label>
                  <ul class="field-box">
                    <li class="first">
                      <input type="radio" name="_1_plan_on_csection" value="Yes" id="_1_plan_on_csection_1" ng-model="cal.plan_on_csection">
                      <label for="_1_plan_on_csection_1"><span></span><?php echo cal_get_field($fields, 'plan_on_csection_1'); ?></label>
                    </li>
                    <li class="second">
                      <input type="radio" name="_1_plan_on_csection" value="No" id="_1_plan_on_csection_2" ng-model="cal.plan_on_csection">
                      <label for="_1_plan_on_csection_2"><span></span><?php echo cal_get_field($fields, 'plan_on_csection_2'); ?></label>
                    </li>
                    <li class="third">
                      <input type="radio" name="_1_plan_on_csection" value="Uncertain" id="_1_plan_on_csection_3" ng-model="cal.plan_on_csection">
                      <label for="_1_plan_on_csection_3"><span></span><?php echo cal_get_field($fields, 'plan_on_csection_3'); ?></label>
                    </li>
                  </ul>
                </li>
                <!-- / main li -->
               <div class="custom-div ddl-active"> 
                <div class="field-left col-md-6">
                  <li ng-if="cal.plan_on_csection != null" ng-init="ddl_change()">
                    <label class="lable-style"><?php echo cal_get_field($fields, 'head_how_many_week'); ?></label>
                    <ul class="field-box">
                      <li>
                        <div class="dropdown-box">
                            <div ng-class="get_device()">
                            	<select name="_1_how_many_week" data-placeholder="<?php echo cal_get_field($fields, 'measure_week_no'); ?>" ng-model="cal.how_many_week" ng-options="index for index in dropdown_number(1, 40)">
                                	<option value=""><?php echo cal_get_field($fields, 'measure_week_no'); ?></option>
                                </select>
                            </div>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <!-- / main li --> 
                </div>
                
				<div ng-if="cal.how_many_week < 36" class="tab1-important row col-md-6 pull-right top-minus">
                  <div class="field-right">
                    <li>
                      <label class="important">IMPORTANT</label>
						<?php echo cal_get_field($fields, 'text_measure_week'); ?>
                      <ul class="field-box ul-inline">
                        <li class="first">
                          <input type="radio" name="_1_measure_week" value="Yes" id="_1_measure_week_1" ng-model="cal.measure_week">
                          <label for="_1_measure_week_1"><span></span><?php echo cal_get_field($fields, 'measure_week_1'); ?></label>
                        </li>
                        <li class="second">
                          <input type="radio" name="_1_measure_week" value="No" id="_1_measure_week_2" ng-model="cal.measure_week">
                          <label for="_1_measure_week_2"><span></span><?php echo cal_get_field($fields, 'measure_week_2'); ?></label>
                        </li>
                      </ul>
                    </li>
                    <!-- / main li -->
                    
                    <li ng-if="cal.measure_week == 'Yes'">
                      <ul class="field-box">
                        <li>
                          <div class="required-field"> <span class="error" ng-show="frmCal._1_email.$error.required">Please, fill in this field</span> <span class="error" ng-show="frmCal._1_email.$error.email">Your email address is invalid</span>
                            <input type="email" name="_1_email" id="_1_email" placeholder="Your Email Goes Here" ng-model="cal.week_email" required>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <!-- / main li --> 
                  </div>
                </div>
               </div> 
			  </div>
              <!-- / .active-no -->
              
            </ul>
          </div>
          
          <div class="button-container"> <a class="btn btn-default btn-lg next tab-click" href="" ng-if="isSteps('step2_a', cal)" data-ng-click="goNext(1)">Next</a> <a class="btn btn-default btn-lg next" href="" ng-if="isSteps('step2_b', cal)" data-ng-click="goNext(2)">Next</a> <div class="save-later"><a href="" data-ng-click="goNext(5)">Save for Later</a></div> </div>
        </div>
        <!-- / #step1 -->
        
        <div id="step1" class="tab-pane fade in active" ng-switch-when="1">
          <div class="tab-head"> 
          <div class="tab-head-img body-weight-img"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'head_tab_img_2'); ?>')}}" /><!--your-weight--></div>
          <span><?php echo cal_get_field($fields, 'head_tab_2'); ?></span>
          <div class="progress-bar-container">
            <div class="progress">
              <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="5" ng-style="{'width':runProgress(cal.nextSteps)}"></div>
            </div>
          </div>
          </div>
          
          <div class="well">
            <ul class="steps">
              <div class="ng-hide" ng-show="cal.give_birth == 'Yes'" ng-init="ddl_change()">
			    <div class="row">
					<div class="field-left col-md-6 border-right ddl-active">
					  <li class="border-bottom">
						<label class="lable-style"><?php echo cal_get_field($fields, 'yes_pregnancy_weight'); ?></label>
						<ul class="field-box">
						  <li>
							<div class="dropdown-box">
                                <div ng-class="get_device()">
                                    <select name="_2_pregnancy_weight" data-placeholder="lbs" ng-model="cal._2_pregnancy_weight" ng-options="index for index in dropdown_number(80, 250)" ng-change="cal._2_heaviest_weight = null; cal_remain_weight_gain(cal);">
                                    	<option value="">lbs</option>
                                    </select>
                                </div>
                            </div>
						  </li>
						</ul>
					  </li>
					  <!-- / main li -->
					  
					  <li class="border-bottom" ng-if="cal._2_pregnancy_weight && (cal._2_pregnancy_weight < 250)" ng-init="ddl_change()">
						<label class="lable-style"><?php echo cal_get_field($fields, 'yes_heaviest_weight'); ?></label>
						<ul class="field-box">
						  <li>
							<div class="dropdown-box">
                                <div ng-class="get_device()">
                                    <select name="_2_heaviest_weight" data-placeholder="lbs" ng-model="cal._2_heaviest_weight" ng-options="index for index in dropdown_number(80, 250) | filter: greaterThan(cal._2_pregnancy_weight)" ng-change="cal._2_weight_now = ''; cal_remain_weight_gain(cal);">
                                    	<option value="">lbs</option>
                                    </select>
                                </div>
                            </div>
						  </li>
						</ul>
					  </li>
					  <!-- / main li -->
					  
					  <li class="border-bottom" ng-if="cal._2_heaviest_weight && (subTotal(cal._2_heaviest_weight, cal._2_pregnancy_weight) > 1)" ng-init="ddl_change()">
						<label class="lable-style"><?php echo cal_get_field($fields, 'yes_weight_now'); ?></label>
						<ul class="field-box">
						  <li>
							<div class="dropdown-box">
                                <div ng-class="get_device()">
                                    <select name="_2_weight_now" data-placeholder="lbs" ng-model="cal._2_weight_now" ng-options="index for index in dropdown_number(80, 250) | filter: greaterThan(cal._2_pregnancy_weight) | filter: lessThan(cal._2_heaviest_weight)" ng-change="cal_remain_weight_gain(cal)">
                                    	<option value="">lbs</option>
                                    </select>
                                </div>
                            </div>
						  </li>
						</ul>
					  </li>
					  <!-- / main li --> 
					</div>
					<div class="field-right col-md-6 pull-right">
					  <li ng-if="(cal.pregnancy_gained > cal.after_childbirth && cal.pregnancy_gained > cal.remain_weight)">
						<ul class="field-box result-box">
						  <li>
							<label><?php echo cal_get_field($fields, 'yes_pregnancy_gained'); ?></label>
							<div class="lb"><strong>{{cal.pregnancy_gained}}</strong> lbs.</div>
							<input type="hidden" name="_2_pregnancy_you_gained" id="_2_pregnancy_you_gained" str-int ng-model="cal.pregnancy_gained" disabled>
						  </li>
						  <li>
							<label><?php echo cal_get_field($fields, 'yes_after_childbirth'); ?></label>
							<div class="lb"><strong>{{cal.after_childbirth}}</strong> lbs.</div>
							<input type="hidden" name="_2_after_childbirth" id="_2_after_childbirth" str-int ng-model="cal.after_childbirth" disabled>
						  </li>
						  <li>
							<label><?php echo cal_get_field($fields, 'yes_remain_weight'); ?></label>
							<div class="lb black"><strong>{{cal.remain_weight}}</strong> lbs.</div>
							<input type="hidden" name="_2_remain_weight" id="_2_remain_weight" str-int ng-model="cal.remain_weight" disabled>
						  </li>
						</ul>
					  </li>
					  <!-- / main li --> 
					</div>
                </div>
			  </div>
              <!-- / .active-yes -->
              
              <div ng-if="cal.give_birth == 'No'" ng-init="ddl_change()">
				<div class="row">
					<div class="field-left col-md-6 border-right">
                  <li class="border-bottom ddl-active">
                    <label class="lable-style"><?php echo cal_get_field($fields, 'no_pregnancy_weight'); ?></label>
                    <ul class="field-box">
                      <li>
                        <div class="dropdown-box">
                            <div ng-class="get_device()">
                                <select name="pregnancy_weight_no" data-placeholder="lbs" ng-model="cal.pregnancy_weight_no" ng-options="index for index in dropdown_number(80, 250)" ng-change="cal.weight_now_no = ''; cal_weight_gain_pregnant(cal)">
                                	<option value="">lbs</option>
                                </select>
                            </div>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <!-- / main li -->
                  
                  <li class="border-bottom ddl-active" ng-if="cal.pregnancy_weight_no && cal.pregnancy_weight_no < 250" ng-init="ddl_change()">
                    <label class="lable-style"><?php echo cal_get_field($fields, 'no_weight_now'); ?></label>
                    <ul class="field-box">
                      <li>
                        <div class="dropdown-box">
                            <div ng-class="get_device()">
                                <select name="weight_now_no" data-placeholder="lbs" ng-model="cal.weight_now_no" ng-options="index for index in dropdown_number(80, 250) | filter: greaterThan(cal.pregnancy_weight_no)" ng-change="cal_weight_gain_pregnant(cal)">
                                	<option value="">lbs</option>
                                </select>
                            </div>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <!-- / main li --> 
                </div>
				<div class="field-right col-md-6 pull-right">
                  <li ng-if="cal.weight_gain_pregnant > 0">
                    <ul class="field-box result-box">
                      <li>
                        <label><?php echo cal_get_field($fields, 'no_pregnancy_gained'); ?></label>
                        <div class="lb"><strong>{{cal.weight_gain_pregnant}}</strong> lbs.</div>
                        <input type="hidden" name="_2_weight_gain_pregnancy" id="_2_weight_gain_pregnancy" ng-model="cal.weight_gain_pregnant" disabled>
                      </li>
                    </ul>
                  </li>
                  <!-- / main li --> 
                </div>
				</div>
			  </div>
              <!-- / .active-no -->
              
            </ul>
          </div>
          
          <div class="button-container"> <a class="btn btn-default pull-left back" href="" data-ng-click="goNext(0)">Back</a> <a class="btn btn-default next" href="" ng-if="isSteps('step3', cal)" data-ng-click="goNext(2)">Next</a> <div class="save-later"><a href="" data-ng-click="goNext(5)">Save for Later</a></div></div>
        </div>
        <!-- / #step2 -->
        
        <div id="step2" class="tab-pane fade in active" ng-switch-when="2">
          <div class="tab-head"> 
          <div class="tab-head-img"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'head_tab_img_3'); ?>')}}" /><!--body-shape--></div>
          <span><?php echo cal_get_field($fields, 'head_tab_3'); ?></span>
          <div class="progress-bar-container">
            <div class="progress">
              <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="5" ng-style="{'width':runProgress(cal.nextSteps)}"></div>
            </div>
          </div>
          </div>
          
          <div class="well" ng-init="ddl_change()">
            <ul class="steps">
				<div class="row">
					<div class="field-left col-md-6 border-style">
                <li>
                  <label class="lable-style"><?php echo cal_get_field($fields, 'tall_are_you'); ?></label>
                  <ul class="field-box">
                    <li>
                      <div class="dropdown-box ddl-active">
                          <div ng-class="get_device()">
                              <select name="_3_tall_are_you" ng-init="custom_options('<?php echo esc_attr($fields->tall_under); ?>', '<?php echo esc_attr($fields->tall_over); ?>')" data-placeholder="<?php echo cal_get_field($fields, 'tall_text'); ?>" ng-model="cal.tall_are_you" ng-options="item.val as item.name for item in items">
                                  <option value=""><?php echo cal_get_field($fields, 'tall_text'); ?></option>
                              </select>
                          </div>
                      </div>
                    </li>
                  </ul>
                </li>
                <!-- / main li -->
                
                <li class="border-top-only" ng-if="cal.tall_are_you != null">
                  <label class="lable-style"><?php echo cal_get_field($fields, 'head_carry_your_weight'); ?></label>
                  <ul class="field-box">
                    <li class="first">
                      <input type="radio" name="_3_carry_your_weight" value="thighs" id="_3_thighs_hips" ng-model="cal.carry_your_weight" ng-change="cal.body_shapes=''">
                      <label for="_3_thighs_hips"><span></span><?php echo cal_get_field($fields, 'carry_your_weight_1'); ?></label>
                    </li>
                    <li class="second">
                      <input type="radio" name="_3_carry_your_weight" value="stomach" id="_3_stomach" ng-model="cal.carry_your_weight" ng-change="cal.body_shapes='Oval'">
                      <label for="_3_stomach"><span></span><?php echo cal_get_field($fields, 'carry_your_weight_2'); ?></label>
                    </li>
                    <li class="third">
                      <input type="radio" name="_3_carry_your_weight" value="chest" id="_3_chest_body" ng-model="cal.carry_your_weight" ng-change="cal.body_shapes='Inverted-Triangle'">
                      <label for="_3_chest_body"><span></span><?php echo cal_get_field($fields, 'carry_your_weight_3'); ?></label>
                    </li>
                    <li class="fourth">
                      <input type="radio" name="_3_carry_your_weight" value="even" id="_3_even" ng-model="cal.carry_your_weight" ng-change="cal.body_shapes='Rectangle'">
                      <label for="_3_even"><span></span><?php echo cal_get_field($fields, 'carry_your_weight_4'); ?></label>
                    </li>
                  </ul>
                </li>
                <!-- / main li --> 
              </div>
				
                <div class="col-md-6 pull right" ng-if="cal.carry_your_weight != null">
                <div class="field-right">
                  <li>
                    <label class="lable-style"><?php echo cal_get_field($fields, 'head_body_shapes'); ?></label>
                    <ul class="steps">
                      <div class="shape-box padding">
                        <div ng-show="cal.carry_your_weight == 'thighs'">
                          <li class="active first">
                            <input type="radio" name="_3_body_shapes" value="Hourglass" id="_3_hourglass" ng-model="cal.body_shapes">
                            <label for="_3_hourglass">
								<div class="body-shape-check"><span></span><?php echo cal_get_field($fields, 'body_shape_name_1'); ?></div>
                                <img ng-src="{{ cal.body_shapes == 'Hourglass' && getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_act_1'); ?>') || getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_in_1'); ?>') }}" alt="Hourglass"  />
							</label>
                          </li>
                          <li class="second">
                            <input type="radio" name="_3_body_shapes" value="Triangle" id="_3_triangle" ng-model="cal.body_shapes">
                            <label for="_3_triangle">
								<div class="body-shape-check"><span></span><?php echo cal_get_field($fields, 'body_shape_name_2'); ?></div>
                                <img ng-src="{{ cal.body_shapes == 'Triangle' && getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_act_2'); ?>') || getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_in_2'); ?>') }}" alt="Triangle"  />
							</label>
                          </li>
                        </div>
                        <div>
                          <li ng-show="cal.carry_your_weight == 'stomach'" class="third">
                            <input type="radio" name="_3_body_shapes" value="Oval" id="_3_oval" ng-model="cal.body_shapes" ng-checked="cal.carry_your_weight=='stomach'">
                            <label for="_3_oval">
                            	<div class="body-shape-check"><span></span><?php echo cal_get_field($fields, 'body_shape_name_3'); ?></div>
                                <img ng-src="{{ cal.body_shapes == 'Oval' && getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_act_3'); ?>') || getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_in_3'); ?>') }}" alt="Oval"  />
							</label>
                          </li>
                          <li ng-show="cal.carry_your_weight == 'even'" class="fourth">
                            <input type="radio" name="_3_body_shapes" value="Rectangle" id="_3_rectangle" ng-model="cal.body_shapes" ng-checked="cal.carry_your_weight=='even'">
                            <label for="_3_rectangle">
                            	<div class="body-shape-check"><span></span><?php echo cal_get_field($fields, 'body_shape_name_5'); ?></div>
                                <img ng-src="{{ cal.body_shapes == 'Rectangle' && getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_act_5'); ?>') || getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_in_5'); ?>') }}" alt="Rectangle"  />
							</label>
                          </li>
                          <li ng-show="cal.carry_your_weight == 'chest'" class="fifth">
                            <input type="radio" name="_3_body_shapes" value="Inverted-Triangle" id="_3_inverted_triangle" ng-model="cal.body_shapes" ng-checked="cal.carry_your_weight=='chest'">
                            <label for="_3_inverted_triangle">
								<div class="body-shape-check"><span></span><?php echo cal_get_field($fields, 'body_shape_name_4'); ?></div>
                                <img ng-src="{{ cal.body_shapes == 'Inverted-Triangle' && getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_act_4'); ?>') || getImage('shapes/<?php echo cal_get_field($fields, 'body_shapes_in_4'); ?>') }}" alt="Inverted-Triangle"  />
							</label>
                          </li>
                        </div>
                      </div>
                      <div class="shape-text padding">
                        <div ng-show="cal.carry_your_weight == 'thighs'">
                          <li class="ng-hide" ng-show="cal.body_shapes == 'Hourglass'"> <span><?php echo cal_get_field($fields, 'body_shape_name_1'); ?></span>
                            <p><?php echo cal_get_field($fields, 'body_shape_text_1'); ?></p>
                          </li>
                          <li class="ng-hide" ng-show="cal.body_shapes == 'Triangle'"> <span><?php echo cal_get_field($fields, 'body_shape_name_2'); ?></span>
                            <p><?php echo cal_get_field($fields, 'body_shape_text_2'); ?></p>
                          </li>
                        </div>
                        <li class="ng-hide" ng-show="cal.body_shapes == 'Oval'"> <span><?php echo cal_get_field($fields, 'body_shape_name_3'); ?></span>
                          <p><?php echo cal_get_field($fields, 'body_shape_text_3'); ?></p>
                        </li>
                        <li class="ng-hide" ng-show="cal.body_shapes == 'Rectangle'"> <span><?php echo cal_get_field($fields, 'body_shape_name_5'); ?></span>
                          <p><?php echo cal_get_field($fields, 'body_shape_text_5'); ?></p>
                        </li>
                        <li class="ng-hide" ng-show="cal.body_shapes == 'Inverted-Triangle'"> <span><?php echo cal_get_field($fields, 'body_shape_name_4'); ?></span>
                          <p><?php echo cal_get_field($fields, 'body_shape_text_4'); ?></p>
                        </li>
                      </div>
                    </ul>
                  </li>
                </div>
              </div>
				</div>
			</ul>
          </div>
          
          <div class="button-container"> <a class="btn btn-default pull-left back" href="" ng-if="isSteps('step2_b', cal)" data-ng-click="goNext(0)">Back</a> <a class="btn btn-default pull-left back" href="" ng-if="isSteps('step2_b', cal) == false" data-ng-click="goNext(1)">Back</a>
          	<a class="btn btn-default next" href="" ng-if="(isSteps('step4', cal) && isSteps('step3', cal) && isSteps('step2_a', cal))" data-ng-click="goNext(3)">Next</a>
            <a class="btn btn-default next" href="" ng-if="(isSteps('step4', cal) && isSteps('step3', cal) && isSteps('step2_b', cal))" data-ng-click="goNext(4); dataSubmit(cal);">Next</a>
            <div class="save-later"><a href="" data-ng-click="goNext(5)">Save for Later</a></div> </div>
        </div>
        <!-- / #step3 -->
        
        <div id="step3" class="tab-pane fade in active" ng-switch-when="3">
          <div class="tab-head"> 
          <div class="tab-head-img"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'head_tab_img_4'); ?>')}}" /></div>
          <span><?php echo cal_get_field($fields, 'head_tab_4'); ?></span>
          <div class="progress-bar-container">
            <div class="progress">
              <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="5" ng-style="{'width':runProgress(cal.nextSteps)}"></div>
            </div>
          </div>
          </div>
          
          <div class="well" ng-init="ddl_change()">
            <ul class="steps">
              <li>
                <label class="lable-style"><?php echo cal_get_field($fields, 'pregnancy_jean_size'); ?></label>
                <ul class="field-box">
                  <li class="after-image">
                    <div class="dropdown-box ddl-active">
                        <div ng-class="get_device()">
                            <select name="_3_pregnancy_jean_size" data-placeholder="<?php echo cal_get_field($fields, 'jean_size_text'); ?>" ng-model="cal.pregnancy_jean_size" ng-options="index for index in range_number(0, 18)">
                            	<option value=""><?php echo cal_get_field($fields, 'jean_size_text'); ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="after-image col-md-7 pull-right"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'jean_size_img'); ?>')}}" /></div>
                  </li>
                </ul>
              </li>
              <!-- / main li -->
              
              <li ng-if="cal.pregnancy_jean_size != null">
                <label class="lable-style"><?php echo cal_get_field($fields, 'head_your_hip_contour'); ?></label>
                <ul class="field-box">
                  <li class="first">
                    <input type="radio" name="_3_your_hip_contour" value="Yes" id="_3_your_hip_contour_1" ng-model="cal.your_hip_contour" class="select-yes" ng-change="cal.measuring_inches = ''">
                    <label for="_3_your_hip_contour_1"><span></span><?php echo cal_get_field($fields, 'your_hip_contour_1'); ?></label>
                  </li>
                  <li class="second">
                    <input type="radio" name="_3_your_hip_contour" value="No" id="_3_your_hip_contour_0" ng-model="cal.your_hip_contour" class="select-no" ng-change="cal.measuring_inches = ''">
                    <label for="_3_your_hip_contour_0"><span></span><?php echo cal_get_field($fields, 'your_hip_contour_2'); ?></label>
                  </li>
                </ul>
              </li>
              <!-- / main li -->
              
              <div ng-if="cal.pregnancy_jean_size && cal.your_hip_contour == 'Yes'" ng-init="ddl_change()">
                <li>
                  <label class="lable-style"><?php echo cal_get_field($fields, 'head_measuring_inches'); ?></label>
                  <ul class="field-box">
                    <li class="after-image">
                      <div class="dropdown-box ddl-active">
                          <div ng-class="get_device()">
                              <select name="_3_measuring_inches" data-placeholder="<?php echo cal_get_field($fields, 'measure_ddl_text'); ?>" ng-model="cal.measuring_inches" ng-options="index for index in point_number(32.5, 52)">
                              	<option value=""><?php echo cal_get_field($fields, 'measure_ddl_text'); ?></option>
                              </select>
                          </div>
                      </div>
                      <div class="after-image col-md-7 pull-right"><img ng-src="{{getImage('<?php echo cal_get_field($fields, 'measuring_inches_img'); ?>')}}" /></div>
                    </li>
                  </ul>
                </li>
                <!-- / main li --> 
              </div>
              <div ng-if="cal.pregnancy_jean_size && cal.your_hip_contour == 'No'">
                <?php 
					$print_pdf_link = cal_get_field($fields, 'printable_measure_pdf');
					$print_pdf_link = ($print_pdf_link)? $print_pdf_link : '#';
				?>
                <li class="download-button message-box">
                <div class="field-left">
				<label><?php echo cal_get_field($fields, 'head_printable_measure'); ?></label>
                <a href="<?php echo $print_pdf_link; ?>" target="_new" class="btn-down download">
                	<img ng-src="{{getImage('<?php echo cal_get_field($fields, 'printable_measure_img'); ?>')}}" />
                </a>
                </div>
                
                <div class="field-right">
                    <?php echo cal_get_field($fields, 'printable_msg_text'); ?>
                </div>
                
                </li>
                
                
                <!-- / main li --> 
              </div>
            </ul>
            <div class="step-measuring" ng-if="cal.pregnancy_jean_size">
              <h3><?php echo cal_get_field($fields, 'head_measure_video'); ?></h3>
              <ul class="steps">
                <li> 
                  <!--<iframe src=""></iframe>-->
                  <?php 
				  		$measure_video_link = cal_get_field($fields, 'measure_video_link');
						if( $measure_video_link ) { ?>
                  <iframe src="<?php echo $measure_video_link; ?>" width="536" height="310" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                  <?php } ?>
                </li>
              </ul>
            </div>
          </div>
          
          <div class="button-container">
              <a class="btn btn-default pull-left back" href="" data-ng-click="goNext(2)">Back</a>
              <a class="btn btn-default next" href="" data-ng-click="goNext(4);" ng-if="isAllSteps(cal)">Next</a>
              <div class="save-later"><a href="" data-ng-click="goNext(5)">Save for Later</a></div>
          </div>
		
        </div>
        <!-- / #step4 --> 
        
      </div>
      <!-- / .tab-content --> 
      
    </div>
    <!-- / .main-step -->
    
    <div ng-if="cal.nextSteps > 3" ng-switch="cal.nextSteps">
        <div class="main-recommend" ng-if="isAllSteps(cal)" ng-switch-when="4">
          <div class="tab-pane fade" ng-init="dataSubmit(cal);" ng-class="{'active in': (cal.nextSteps == '4')}">
            <div class="well">
              <div class="recommend-box green">
                <h3><?php echo cal_get_field($fields, 'head_recommended_size'); ?></h3>
                
                <div ng-if="cal.your_hip_contour == 'Yes' && rec_size != 'Call for Sizing'" class="msg-center">
                  <h4>{{rec_size}}</h4>
                  <p>For <strong>immediate</strong> postpartum support</p>
                </div>
                
                <div ng-hide="cal.your_hip_contour == 'Yes' && rec_size != 'Call for Sizing'" class="msg-center">
                  <div class="alert-img">
                      <img ng-src="{{getImage('alert.png')}}" alt="" />
                  </div>
                  
                  <div class="alert-msg">
                      <div ng-if="isSteps('step2_b', cal)">
                        <?php echo cal_get_field($fields, 'msg_under_36_week'); ?>
                      </div>
                      
                      <div ng-if="cal.your_hip_contour == 'No'">
                        <?php echo cal_get_field($fields, 'msg_no_hip_contour'); ?>
                        
                        <a class="btn btn-default pull-left back" href="" data-ng-click="goNext(cal.prevSteps)">Go Back To Measure My Hips</a>
                      </div>
                      
                      <div ng-if="cal.your_hip_contour == 'Yes' && rec_size == 'Call for Sizing'">
                        <?php echo cal_get_field($fields, 'msg_call_for_size'); ?>
                      </div>
                  </div>
                </div>
                
              </div>
              <div class="reminder" ng-if="cal.how_many_week < 36">
                    <div ng-if="cal.measure_week == 'Yes' || subscribe == 'success'"> <!-- yes -->
                        <div class="rem-full">
                            <p><?php echo cal_get_field($fields, 'msg_email_yes'); ?> <span>{{cal.week_email}}</span> In</p>
                            <strong class="week-reminder">{{(36) - (cal.how_many_week)}} weeks</strong>
                        </div>
                    </div>
                    <!-- / yes -->
                    
                    <div ng-if="cal.measure_week == 'No' && subscribe != 'success'"> <!-- no -->
                        <div class="rem-left">
                            <p><?php echo cal_get_field($fields, 'msg_email_no'); ?></p>
                            <strong class="week-reminder">{{(36) - (cal.how_many_week)}} weeks</strong>
                        </div>
                        
                        <div class="rem-right">
                            <div class="required-field"> <span class="error" ng-show="frmCal._1_email.$error.required">Please, fill in this field</span> <span class="error" ng-show="frmCal._1_email.$error.email">Your email address is invalid</span>
                            	<input type="email" name="_1_email" id="_1_email" placeholder="Your Email Goes Here" ng-model="cal.week_email" required>
                            </div>
                            
                            <div class="email-submit">
                                <button type="button" class="btn-email" data-ng-click="resultSubscribe(cal)" ng-disabled="( cal.week_email == null )">Remind Me</button>
                            </div>
                        </div>
                    </div>
                    <!-- / no -->
                    
              </div>
              
              <div class="text-alert" ng-if="isSteps('step2_b', cal) || cal.your_hip_contour == 'No'">
              <?php echo cal_get_field($fields, 'msg_alert_box'); ?></div>
              
              <div class="recommend-box rc-box1">
                <h3><?php echo cal_get_field($fields, 'head_recommended_style'); ?></h3>
                <ul class="steps">
                  <li ng-repeat="style in rec_styles">
                    <div class="image" ng-if="style.img"><img ng-src="{{style.img}}" alt="{{style.title}}" /></div>
                    <div class="title" ng-bind-html="style.title"></div>
                    <div class="price" ng-if="style.price">Regular Price: <span ng-class="{'cut':style.sale_price}" ng-bind-html="style.price"></span> </div>
                    <div class="sale_price" ng-if="style.sale_price" ng-bind-html="style.sale_price"></div>
                    <div class="link" ng-if="isSteps('step2_b', cal)"><a href="{{style.link}}">Check It Out</a></div>
                    <div class="link" ng-if="! isSteps('step2_b', cal)"><a href="{{style.link}}">Get Your Size</a></div>
                  </li>
                </ul>
              </div>
              <div class="recommend-box rc-box2">
                <h3><?php echo cal_get_field($fields, 'head_recommended_bundle'); ?></h3>
                <ul class="steps">
                  <li ng-repeat="bundle in rec_bundles">
                    <div class="image" ng-if="bundle.img"><img ng-src="{{bundle.img}}" alt="{{bundle.title}}" /></div>
                    <div class="title" ng-bind-html="bundle.title"></div>
                    <div class="price" ng-if="bundle.price">Regular Price: <span ng-class="{'cut':bundle.sale_price}" ng-bind-html="bundle.price"></span> </div>
                    <div class="sale_price" ng-if="bundle.sale_price">
                      <div ng-bind-html="bundle.sale_price"></div>
                    </div>
                    <div class="link"><a href="{{bundle.link}}">Get {{bundle.sku}}</a></div>
                  </li>
                </ul>
              </div>
              <div class="recommend-box rc-box3 space">
                <h3><?php echo cal_get_field($fields, 'head_additional_option'); ?></h3>
                <ul class="steps">
                  <li class="w-half pull-left">
                    <div class="required-field"> <span class="error" ng-show="frmCal.email.$error.required">Please, fill in this field</span> <span class="error" ng-show="frmCal.email.$error.email">Your email address is invalid</span>
                      <input type="email" name="email" placeholder="Type your Email here" ng-model="cal.result_email" required>
                    </div>
                  </li>
                  <li class="w-half pull-right">
                    <input type="checkbox" id="need_to_speak" name="need_to_speak" ng-model="cal.need_to_speak">
                    <label for="need_to_speak"><span></span>
                        <div class="email-lable-text"><?php echo cal_get_field($fields, 'head_need_to_speak'); ?></div>
                    </label>
                  </li>
                  <div class="phonestyle" ng-if="cal.need_to_speak">
                    <li class="w-half">
                      <input type="text" name="phone" placeholder="Your Phone number goes here" ng-model="cal.phone">
                    </li>
                    <li class="w-half pull-right">
                      <input type="text" name="fullname" placeholder="Your Name" ng-model="cal.fullname">
                    </li>
                  </div>
                  <li class="email-submit"> <a class="btn-email" href="javascript:;" data-ng-click="resultSubmit(cal)" ng-hide="( cal.result_email == null ) || res_result.status == 'success'"><?php echo cal_get_field($fields, 'head_email_button'); ?></a> <strong ng-if="res_result.status == 'success'">{{res_result.html}}</strong> </li>
                </ul>
              </div>
            </div>
            
            <div class="button-container recommend-btn"> <a class="btn btn-default pull-left back" href="" data-ng-click="goNext(cal.prevSteps)">Back</a> <a class="btn btn-default btn-success first" href="" data-ng-click="goNext(0); reset_calculation();">Start Over</a> </div>
          </div>
          <!-- / #step5 --> 
          
        </div>
        <!-- / .main-recommend -->
        
        <div id="step5" class="main-save" ng-switch-when="5">
          <div class="well">
            <div class="save-box">
              <h3>Save My Sizing Session</h3>
              <ul class="steps">
                <li>
                  <p>Save this link to return later from any device. Link valid for 30 days.</p>
                </li>
                
                <li>
                	<div class="save-link">
					  <?php $save_link = get_permalink() . "?action=retrive_form&token="; ?>
                      <span id="save-link" data-ng-click="dataSave(cal, 'link')"><?php echo $save_link; ?>{{cal.uniqid}}</span>
                    </div>
                    
                    <a href="javascript:;" class="copy-link" data-clipboard-target="#save-link" data-ng-click="dataSave(cal, 'link')">Copy Link</a>
                </li>
                
                <li ng-if="res_save.status == 'success' && res_save.action == 'email'"> ALL SET! The Link was sent to the following email address: <br />
                  {{cal.save_email}} </li>
                
                <li ng-hide="res_save.status == 'success' && res_save.action == 'email'">
                  <div class="required-field"> <span class="error" ng-show="frmCal.save_email.$error.required">Please, fill in this field</span> <span class="error" ng-show="frmCal.save_email.$error.email">Your email address is invalid</span>
                    <input type="email" name="save_email" placeholder="Your email goes here" ng-model="cal.save_email" required>
                  </div>
                  
                  <button type="button" data-ng-click="dataSave(cal, 'mail')" ng-disabled="( cal.save_email == null )">Email me the Link</button>
                </li>
              </ul>
            </div>
          </div>
          
          <div class="button-container"> <a href="javascript:;" class="btn btn-default pull-left back" data-ng-click="goNext(cal.prevSteps)">Back</a> </div>
        </div>
        
    </div>
    <!-- / hashSteps -->
    
  </form>
</div>
<script type='text/javascript'>
jQuery(document).ready(function() {
	var clipboard = new Clipboard('.copy-link');
	clipboard.on('success', function(e) {
		e.clearSelection();
	});
});
</script>